# Hostel Room Allocation Management System

A premium, modern Web Application for managing student hostel room allocations, room inventory, complaints, and payments.

## Features

- **Authentication & Security**: Role-based access control (Admin & Student) secured using JSON Web Tokens (JWT) and encrypted passwords (bcryptjs).
- **Admin Dashboard**: Live statistics of the hostel showing total students, total rooms, occupancy levels, and pending requests.
- **Student Profiles**: Dynamic student record management (CRUD operations).
- **Rooms Management**: Inventory management including block, floor, capacity, and vacancy calculations.
- **Room Allocation Flow**: Automated allocation requesting, manual assignments, approvals, rejections, and vacating, with occupancy metrics recalculated at every status change.
- **Complaints Registry**: Custom category tickets with tracking for resolved feedback.
- **Mock Payments Ledger**: Logging mock student fees and transaction verification logs.

---

## Technologies Used

- **Frontend**: HTML5, CSS3 (Vanilla Glassmorphic Design System), Vanilla JavaScript (ES6 fetch API)
- **Backend**: Node.js, Express.js
- **Database**: MySQL (relational constraints and transactions)

---

## Project Structure

```text
hostel-management-system/
├── backend/
│   ├── config/
│   │   └── db.js               # MySQL promise-based pool configuration
│   ├── middleware/
│   │   ├── authMiddleware.js   # JWT verification middleware
│   │   └── roleMiddleware.js   # Role-based restriction middleware
│   ├── routes/
│   │   ├── authRoutes.js       # Student registration and user login
│   │   ├── adminRoutes.js      # Dashboard metrics API
│   │   ├── studentRoutes.js    # Student directory CRUD APIs
│   │   ├── roomRoutes.js       # Rooms inventory APIs
│   │   ├── allocationRoutes.js # Approvals, vacating, and assigning rooms
│   │   ├── complaintRoutes.js  # Complaint registry APIs
│   │   └── paymentRoutes.js    # Mock payment transactions APIs
│   ├── scripts/
│   │   └── seedAdmin.js        # Table migrator and default admin seeder
│   ├── .env.example            # Environment variables template
│   ├── package.json            # Backend scripts and dependencies
│   └── server.js               # Main Express app and routes
├── frontend/
│   ├── css/
│   │   ├── style.css           # Global typography, colors, scrollbars, and modals
│   │   ├── admin.css           # Navigation sidebars and listings
│   │   ├── dashboard.css       # Metrics cards and progress rate bars
│   │   └── auth.css            # Logins and registrations forms
│   ├── js/
│   │   ├── api.js              # Fetch requests with JWT headers
│   │   ├── auth.js             # Layout rendering engine
│   │   ├── login.js            # Login verification
│   │   ├── register.js         # Student registration
│   │   ├── admin.js            # Admin dashboard counters
│   │   ├── students.js         # Students CRUD dashboard
│   │   ├── rooms.js            # Rooms inventory dashboard
│   │   ├── allocations.js      # Allocation approvals and status controls
│   │   ├── complaints.js       # Complaints log and responses
│   │   ├── payments.js         # Payments record logger
│   │   └── student-dashboard.js# Student dashboard profile and room requests
│   ├── index.html              # Main Login Page
│   ├── register.html           # Student Registration Page
│   ├── admin.html              # Admin Dashboard
│   ├── student.html            # Student Portal Dashboard
│   ├── students.html           # Admin: Students directory
│   ├── rooms.html              # Admin: Rooms inventory
│   ├── allocations.html        # Admin: Room assignments queue
│   ├── complaints.html         # Common: Complaints manager
│   └── payments.html           # Common: Payment logs ledger
├── database/
│   └── schema.sql              # Clean database tables layout
└── README.md
```

---

## Getting Started

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (v16 or higher)
- [MySQL Server](https://dev.mysql.com/downloads/installer/) (v8 or higher)

### 2. Database & Environment Configuration
1. Open your MySQL client and ensure MySQL service is running.
2. In the `backend/` directory, copy `.env.example` to a new file named `.env`:
   ```bash
   cp backend/.env.example backend/.env
   ```
3. Open `backend/.env` and update the database configuration:
   ```env
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=YOUR_MYSQL_ROOT_PASSWORD
   DB_NAME=hostel_management
   JWT_SECRET=change_this_secret_key_12345
   ```

### 3. Installation
Navigate to the `backend/` folder and install package dependencies:
```bash
cd backend
npm install
```

### 4. Database Initialization & Seeding
Run the seeder command to automatically create the database `hostel_management`, import tables from `database/schema.sql`, and insert the default Administrator account:
```bash
npm run seed
```

**Default Admin Credentials:**
- **Email**: `admin@hostel.com`
- **Password**: `Admin@123`

### 5. Running the Application
1. **Start the Backend API Server**:
   From the `backend/` folder, run:
   ```bash
   npm run dev
   ```
   The backend API will run at: `http://localhost:5000/api`

2. **Open the Frontend**:
   Since the frontend is built with pure Vanilla HTML/CSS/JS, you can serve it using any simple HTTP server. For example:
   - Run `npx serve ../frontend` or `npx live-server ../frontend` inside the backend directory.
   - Or simply double-click and open `frontend/index.html` in your web browser! (Note: Running via a local server like Live Server or VS Code Live Server is recommended for absolute URL routing consistency).

---

## API Documentation

### Authentication Routing (`/api/auth`)
- `POST /api/auth/register` - Registers a student user + profile in one transaction.
- `POST /api/auth/login` - Authenticates user; returns a signed JWT and profile details.

### Admin Dashboard Routing (`/api/admin`)
- `GET /api/admin/dashboard-stats` - Retrieves statistics for occupied rooms, pending allocations, and ticket counts.

### Student Management Routing (`/api/students`)
- `GET /api/students` - Retrieves all student profiles (Admin only).
- `GET /api/students/:id` - Retrieves profile details for a student. Handles `:id` = `me` to fetch current user's profile.
- `POST /api/students` - Creates student + user credentials manually (Admin only).
- `PUT /api/students/:id` - Updates student profiles.
- `DELETE /api/students/:id` - Removes the user and triggers cascade deletes (Admin only).

### Rooms Routing (`/api/rooms`)
- `GET /api/rooms` - Lists all rooms (supports query filters for blocks, types, status).
- `POST /api/rooms` - Creates a new room (Admin only).
- `PUT /api/rooms/:id` - Updates room block/floor details or capacities (Admin only).
- `DELETE /api/rooms/:id` - Deletes a room if it has 0 occupied beds (Admin only).

### Allocation Routing (`/api/allocations`)
- `GET /api/allocations` - Lists allocations (Admin gets all, Student gets own).
- `POST /api/allocations` - Creates allocation request (Student defaults to `Pending`, Admin immediately gets `Approved`).
- `PUT /api/allocations/:id/approve` - Approves request and increments occupied beds (Admin only).
- `PUT /api/allocations/:id/reject` - Rejects allocation request (Admin only).
- `PUT /api/allocations/:id/vacate` - Sets status to `Vacated` and decrements room occupancy (Admin only).

### Complaints Routing (`/api/complaints`)
- `GET /api/complaints` - Lists complaints (Admin gets all, Student gets own).
- `POST /api/complaints` - Submits a complaint category ticket (Student only).
- `PUT /api/complaints/:id` - Responds to complaint and changes status (Admin only).

### Payments Routing (`/api/payments`)
- `GET /api/payments` - Lists payment histories (Admin gets all, Student gets own).
- `POST /api/payments` - Submits payment log references (Student only).
- `PUT /api/payments/:id` - Updates payment status (Admin only).

---

## Troubleshooting

- **Database Connection Refused**:
  - Verify that MySQL Server is running.
  - Verify the port and password configuration in `backend/.env`.
- **JWT Authentication Errors**:
  - Ensure the request header includes the prefix `Bearer ` followed by the token.
- **Port 5000 is occupied**:
  - Edit `PORT` variable in the `backend/.env` file and restart.
