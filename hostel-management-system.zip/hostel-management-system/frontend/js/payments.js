// Payment Management Page Controller

let paymentsData = [];

document.addEventListener('DOMContentLoaded', () => {
  requireAuth();

  const user = getUser();
  
  // Set UI elements based on role
  const studentActionBtn = document.getElementById('student-action-btn');
  if (studentActionBtn) {
    studentActionBtn.style.display = user.role === 'student' ? 'block' : 'none';
  }

  // Load Payments List
  loadPayments();

  // Search/Filters Events
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', applySearchFilters);
  }

  const filterStatus = document.getElementById('filter-status');
  if (filterStatus) {
    filterStatus.addEventListener('change', applySearchFilters);
  }

  // Modal Setup
  setupModals();
});

// Load payments
async function loadPayments() {
  const tableBody = document.getElementById('payments-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading payment logs...</td></tr>';

  try {
    const res = await apiRequest('/payments', 'GET');
    if (res.success && res.data) {
      paymentsData = res.data;
      renderPayments(paymentsData);
    }
  } catch (error) {
    showToast('Failed to load payments ledger', 'error');
    tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--color-danger);">Failed to load payment logs.</td></tr>';
  }
}

// Render payments table
function renderPayments(payments) {
  const tableBody = document.getElementById('payments-table-body');
  if (!tableBody) return;

  if (payments.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No payment transactions recorded.</td></tr>';
    return;
  }

  const user = getUser();
  tableBody.innerHTML = '';
  
  payments.forEach(pay => {
    const tr = document.createElement('tr');
    
    let statusClass = 'badge-warning';
    if (pay.status === 'Paid') statusClass = 'badge-success';
    else if (pay.status === 'Failed') statusClass = 'badge-danger';

    const payDate = new Date(pay.payment_date).toLocaleDateString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric'
    });

    let actionHTML = '';
    if (user.role === 'admin') {
      actionHTML = `
        <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px; color: var(--color-success);" onclick="updatePaymentStatus(${pay.id}, 'Paid')">✔️ Paid</button>
        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="updatePaymentStatus(${pay.id}, 'Failed')">❌ Fail</button>
      `;
    } else {
      actionHTML = `<span style="font-size: 13px; color: var(--text-muted);">Verified</span>`;
    }

    tr.innerHTML = `
      <td><strong>TXN-${pay.id}</strong></td>
      ${user.role === 'admin' ? `<td>${pay.student_name} (${pay.student_roll_no})</td>` : ''}
      <td>$${parseFloat(pay.amount).toFixed(2)}</td>
      <td>${payDate}</td>
      <td>${pay.payment_method}</td>
      <td><code>${pay.transaction_id}</code></td>
      <td><span class="badge ${statusClass}">${pay.status}</span></td>
      ${user.role === 'admin' ? `<td>${actionHTML}</td>` : ''}
    `;
    tableBody.appendChild(tr);
  });
}

// Search and Filter Payments
function applySearchFilters() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const status = document.getElementById('filter-status').value;
  const user = getUser();

  const filtered = paymentsData.filter(pay => {
    const matchesQuery = 
      pay.transaction_id.toLowerCase().includes(query) ||
      pay.payment_method.toLowerCase().includes(query) ||
      (user.role === 'admin' && pay.student_name.toLowerCase().includes(query));

    const matchesStatus = !status || pay.status === status;

    return matchesQuery && matchesStatus;
  });

  renderPayments(filtered);
}

// Setup Payment Modals
function setupModals() {
  const payForm = document.getElementById('log-payment-form');
  if (payForm) {
    payForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const payload = {
        amount: document.getElementById('pay-amount').value,
        payment_method: document.getElementById('pay-method').value,
        transaction_id: document.getElementById('pay-txn-id').value.trim(),
        payment_date: document.getElementById('pay-date').value
      };

      if (!payload.amount || !payload.payment_method || !payload.transaction_id || !payload.payment_date) {
        showToast('All fields are required', 'warning');
        return;
      }

      try {
        const response = await apiRequest('/payments', 'POST', payload);
        if (response.success) {
          showToast('Payment log submitted successfully', 'success');
          closeModal('payment-modal');
          payForm.reset();
          loadPayments();
        }
      } catch (error) {
        showToast(error.message || 'Failed to submit payment log', 'error');
      }
    });
  }
}

// Admin Action: Update Payment Status
async function updatePaymentStatus(id, status) {
  if (!confirm(`Are you sure you want to mark this transaction as ${status.toUpperCase()}?`)) return;

  try {
    const res = await apiRequest(`/payments/${id}`, 'PUT', { status });
    if (res.success) {
      showToast(`Payment status updated to ${status}`, 'success');
      loadPayments();
    }
  } catch (error) {
    showToast(error.message || 'Failed to update payment status', 'error');
  }
}

// Modal helper controls
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'flex';
}

// Exported for button click in HTML
function openPaymentModal() {
  openModal('payment-modal');
  // Set default date to today
  const dateInput = document.getElementById('pay-date');
  if (dateInput) {
    dateInput.value = new Date().toISOString().split('T')[0];
  }
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}
