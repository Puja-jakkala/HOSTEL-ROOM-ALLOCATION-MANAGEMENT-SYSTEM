// Student Management Page Controller

let studentsData = [];

document.addEventListener('DOMContentLoaded', () => {
  requireAdmin();

  // Load students list
  loadStudents();

  // Search and Filter Listeners
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', applySearchFilters);
  }

  const filterStatus = document.getElementById('filter-status');
  if (filterStatus) {
    filterStatus.addEventListener('change', applySearchFilters);
  }

  const filterGender = document.getElementById('filter-gender');
  if (filterGender) {
    filterGender.addEventListener('change', applySearchFilters);
  }

  // Modal Setup
  setupModals();
});

// Load all students
async function loadStudents() {
  const tableBody = document.getElementById('students-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">Loading students...</td></tr>';

  try {
    const response = await apiRequest('/students', 'GET');
    if (response.success && response.data) {
      studentsData = response.data;
      renderStudents(studentsData);
    }
  } catch (error) {
    showToast('Failed to load students list', 'error');
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--color-danger);">Failed to load students.</td></tr>';
  }
}

// Render student array into table
function renderStudents(students) {
  const tableBody = document.getElementById('students-table-body');
  if (!tableBody) return;

  if (students.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No students found.</td></tr>';
    return;
  }

  tableBody.innerHTML = '';
  students.forEach(student => {
    const tr = document.createElement('tr');
    
    const badgeClass = student.status === 'Active' ? 'badge-success' : 'badge-danger';
    
    tr.innerHTML = `
      <td><strong>${student.student_id}</strong></td>
      <td>${student.name}</td>
      <td>${student.email}</td>
      <td>${student.phone}</td>
      <td>${student.gender}</td>
      <td>${student.course} (${student.year} Year)</td>
      <td><span class="badge ${badgeClass}">${student.status}</span></td>
      <td>
        <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px;" onclick="viewStudent(${student.id})">👁️ View</button>
        <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px; color: var(--color-primary);" onclick="openEditStudentModal(${student.id})">✏️ Edit</button>
        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="confirmDeleteStudent(${student.id}, '${student.name}')">🗑️ Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

// Filter and Search Client-side logic
function applySearchFilters() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const status = document.getElementById('filter-status').value;
  const gender = document.getElementById('filter-gender').value;

  const filtered = studentsData.filter(student => {
    const matchesQuery = 
      student.name.toLowerCase().includes(query) ||
      student.email.toLowerCase().includes(query) ||
      student.student_id.toLowerCase().includes(query) ||
      student.course.toLowerCase().includes(query) ||
      student.department.toLowerCase().includes(query);

    const matchesStatus = !status || student.status === status;
    const matchesGender = !gender || student.gender === gender;

    return matchesQuery && matchesStatus && matchesGender;
  });

  renderStudents(filtered);
}

// Modal handling logic
function setupModals() {
  // Add Student Submit
  const addForm = document.getElementById('add-student-form');
  if (addForm) {
    addForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const payload = {
        name: document.getElementById('add-name').value.trim(),
        email: document.getElementById('add-email').value.trim(),
        student_id: document.getElementById('add-roll').value.trim(),
        phone: document.getElementById('add-phone').value.trim(),
        gender: document.getElementById('add-gender').value,
        department: document.getElementById('add-dept').value.trim(),
        course: document.getElementById('add-course').value.trim(),
        year: document.getElementById('add-year').value,
        emergency_contact: document.getElementById('add-emergency').value.trim(),
        address: document.getElementById('add-address').value.trim(),
        status: document.getElementById('add-status').value
      };

      try {
        const response = await apiRequest('/students', 'POST', payload);
        if (response.success) {
          showToast('Student added successfully', 'success');
          closeModal('add-student-modal');
          addForm.reset();
          loadStudents();
        }
      } catch (error) {
        showToast(error.message || 'Failed to create student', 'error');
      }
    });
  }

  // Edit Student Submit
  const editForm = document.getElementById('edit-student-form');
  if (editForm) {
    editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const studentId = document.getElementById('edit-student-id').value;

      const payload = {
        name: document.getElementById('edit-name').value.trim(),
        email: document.getElementById('edit-email').value.trim(),
        phone: document.getElementById('edit-phone').value.trim(),
        gender: document.getElementById('edit-gender').value,
        department: document.getElementById('edit-dept').value.trim(),
        course: document.getElementById('edit-course').value.trim(),
        year: document.getElementById('edit-year').value,
        emergency_contact: document.getElementById('edit-emergency').value.trim(),
        address: document.getElementById('edit-address').value.trim(),
        status: document.getElementById('edit-status').value
      };

      try {
        const response = await apiRequest(`/students/${studentId}`, 'PUT', payload);
        if (response.success) {
          showToast('Student profile updated successfully', 'success');
          closeModal('edit-student-modal');
          loadStudents();
        }
      } catch (error) {
        showToast(error.message || 'Failed to update student profile', 'error');
      }
    });
  }
}

// Modal Toggle helpers
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'flex';
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}

// view student profile modal
async function viewStudent(id) {
  try {
    const res = await apiRequest(`/students/${id}`, 'GET');
    if (res.success && res.data) {
      const student = res.data;
      
      document.getElementById('view-name').textContent = student.name;
      document.getElementById('view-roll').textContent = student.student_id;
      document.getElementById('view-email').textContent = student.email;
      document.getElementById('view-phone').textContent = student.phone;
      document.getElementById('view-gender').textContent = student.gender;
      document.getElementById('view-dept').textContent = student.department;
      document.getElementById('view-course').textContent = student.course;
      document.getElementById('view-year').textContent = `${student.year} Year`;
      document.getElementById('view-emergency').textContent = student.emergency_contact;
      document.getElementById('view-address').textContent = student.address;
      document.getElementById('view-status').textContent = student.status;
      
      openModal('view-student-modal');
    }
  } catch (error) {
    showToast('Failed to retrieve student profile info', 'error');
  }
}

// Edit Modal Loader
async function openEditStudentModal(id) {
  try {
    const res = await apiRequest(`/students/${id}`, 'GET');
    if (res.success && res.data) {
      const student = res.data;
      
      document.getElementById('edit-student-id').value = student.id;
      document.getElementById('edit-name').value = student.name;
      document.getElementById('edit-email').value = student.email;
      document.getElementById('edit-roll').value = student.student_id;
      document.getElementById('edit-phone').value = student.phone;
      document.getElementById('edit-gender').value = student.gender;
      document.getElementById('edit-dept').value = student.department;
      document.getElementById('edit-course').value = student.course;
      document.getElementById('edit-year').value = student.year;
      document.getElementById('edit-emergency').value = student.emergency_contact;
      document.getElementById('edit-address').value = student.address;
      document.getElementById('edit-status').value = student.status;
      
      openModal('edit-student-modal');
    }
  } catch (error) {
    showToast('Failed to retrieve student profile info', 'error');
  }
}

// Delete Confirmation trigger
let pendingDeleteId = null;
function confirmDeleteStudent(id, name) {
  pendingDeleteId = id;
  document.getElementById('delete-student-name').textContent = name;
  openModal('delete-student-modal');
}

async function executeDeleteStudent() {
  if (!pendingDeleteId) return;

  try {
    const res = await apiRequest(`/students/${pendingDeleteId}`, 'DELETE');
    if (res.success) {
      showToast('Student deleted successfully', 'success');
      closeModal('delete-student-modal');
      loadStudents();
    }
  } catch (error) {
    showToast('Failed to delete student', 'error');
  } finally {
    pendingDeleteId = null;
  }
}
