// Student Registration Page Controller

document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('register-form');
  const errorMessage = document.getElementById('error-message');
  const submitBtn = document.getElementById('submit-btn');
  const btnText = document.getElementById('btn-text');
  const btnSpinner = document.getElementById('btn-spinner');

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Gather input data
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const student_id = document.getElementById('student_id').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const gender = document.getElementById('gender').value;
      const department = document.getElementById('department').value.trim();
      const course = document.getElementById('course').value.trim();
      const year = document.getElementById('year').value;
      const address = document.getElementById('address').value.trim();
      const emergency_contact = document.getElementById('emergency_contact').value.trim();

      // Basic validation check
      if (
        !name || !email || !password || !student_id || !phone || 
        !gender || !department || !course || !year || !address || !emergency_contact
      ) {
        showError('Please fill in all fields.');
        return;
      }

      // Hide previous error, show spinner
      errorMessage.style.display = 'none';
      setLoading(true);

      const payload = {
        name,
        email,
        password,
        student_id,
        phone,
        gender,
        department,
        course,
        year: parseInt(year),
        address,
        emergency_contact
      };

      try {
        await apiRequest('/auth/register', 'POST', payload);
        
        showToast('Registration successful! Redirecting to login...', 'success');

        setTimeout(() => {
          window.location.href = 'login.html';
        }, 1500);

      } catch (error) {
        showError(error.message || 'Registration failed. Check details or contact Administrator.');
        setLoading(false);
      }
    });
  }

  // Helper to show errors
  function showError(msg) {
    errorMessage.textContent = msg;
    errorMessage.style.display = 'flex';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Helper to show/hide loading spinner
  function setLoading(isLoading) {
    if (isLoading) {
      submitBtn.disabled = true;
      btnText.style.display = 'none';
      btnSpinner.style.display = 'block';
    } else {
      submitBtn.disabled = false;
      btnText.style.display = 'block';
      btnSpinner.style.display = 'none';
    }
  }
});
