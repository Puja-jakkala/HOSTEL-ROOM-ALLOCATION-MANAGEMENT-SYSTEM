// Login Page Logic Controller

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const togglePasswordBtn = document.getElementById('toggle-password');
  const errorMessage = document.getElementById('error-message');
  const submitBtn = document.getElementById('submit-btn');
  const btnText = document.getElementById('btn-text');
  const btnSpinner = document.getElementById('btn-spinner');

  // Toggle Password Visibility
  if (togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      togglePasswordBtn.textContent = type === 'password' ? '👁️' : '🔒';
    });
  }

  // Handle Form Submission
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = emailInput.value.trim();
      const password = passwordInput.value;

      if (!email || !password) {
        showError('Please fill in all fields.');
        return;
      }

      // Hide previous error, show spinner
      errorMessage.style.display = 'none';
      setLoading(true);

      try {
        const response = await apiRequest('/auth/login', 'POST', { email, password });
        
        // Save session in localStorage
        saveSession(response.token, response.user);

        showToast('Login successful! Redirecting...', 'success');

        // Redirect based on role
        setTimeout(() => {
          if (response.user.role === 'admin') {
            window.location.href = 'admin.html';
          } else {
            window.location.href = 'student.html';
          }
        }, 1000);

      } catch (error) {
        showError(error.message || 'Invalid email or password.');
        setLoading(false);
      }
    });
  }

  // Helper to show errors
  function showError(msg) {
    errorMessage.textContent = msg;
    errorMessage.style.display = 'flex';
  }

  // Helper to show/hide loading spinner
  function setLoading(isLoading) {
    if (isLoading) {
      submitBtn.disabled = true;
      btnText.style.display = 'none';
      btnSpinner.style.display = 'block';
    } else {
      submitBtn.disabled = false;
      btnText.style.display = 'block';
      btnSpinner.style.display = 'none';
    }
  }
});
