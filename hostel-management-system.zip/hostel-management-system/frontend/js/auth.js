// Common Authentication and UI Layout Initializer

document.addEventListener('DOMContentLoaded', () => {
  // Determine current page
  const path = window.location.pathname;
  const pageName = path.substring(path.lastIndexOf('/') + 1);

  // Skip auth checks on landing, login, and registration pages
  if (pageName === 'index.html' || pageName === 'login.html' || pageName === 'register.html' || pageName === '') {
    // If already logged in and visiting login or register page, redirect them to dashboard
    const token = getToken();
    const user = getUser();
    if (token && user && (pageName === 'login.html' || pageName === 'register.html')) {
      if (user.role === 'admin') {
        window.location.href = 'admin.html';
      } else {
        window.location.href = 'student.html';
      }
    }
    return;
  }

  // 1. Enforce Authentication
  requireAuth();

  // 2. Render Shared Shell layout (Sidebar and Header)
  renderShell();
});

// Render the admin or student layout template
function renderShell() {
  const user = getUser();
  if (!user) return;

  // Render Sidebar
  const sidebarContainer = document.getElementById('sidebar-container');
  if (sidebarContainer) {
    const isReady = requireAuth();
    if (!isReady) return;

    const path = window.location.pathname;
    const pageName = path.substring(path.lastIndexOf('/') + 1) || 'admin.html';

    let menuItems = [];

    if (user.role === 'admin') {
      menuItems = [
        { label: 'Dashboard', link: 'admin.html', icon: '📊' },
        { label: 'Students', link: 'students.html', icon: '👥' },
        { label: 'Rooms', link: 'rooms.html', icon: '🛏️' },
        { label: 'Allocations', link: 'allocations.html', icon: '🔑' },
        { label: 'Complaints', link: 'complaints.html', icon: '⚠️' },
        { label: 'Payments', link: 'payments.html', icon: '💳' }
      ];
    } else {
      menuItems = [
        { label: 'Dashboard', link: 'student.html', icon: '🏠' },
        { label: 'Complaints', link: 'complaints.html', icon: '⚠️' },
        { label: 'Payments', link: 'payments.html', icon: '💳' }
      ];
    }

    let sidebarHTML = `
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
          <span style="font-size: 24px;">🏢</span>
          <div class="sidebar-logo-text">HMS Portal</div>
        </div>
        <ul class="sidebar-menu">
    `;

    menuItems.forEach(item => {
      const isActive = pageName === item.link;
      sidebarHTML += `
        <li class="sidebar-item ${isActive ? 'active' : ''}">
          <a href="${item.link}">
            <span>${item.icon}</span>
            <span>${item.label}</span>
          </a>
        </li>
      `;
    });

    sidebarHTML += `
        </ul>
        <div class="sidebar-footer">
          <button class="btn btn-secondary" id="logout-btn" style="width: 100%; display: flex; justify-content: center; gap: 8px;">
            <span>🚪</span> Logout
          </button>
        </div>
      </aside>
    `;

    sidebarContainer.innerHTML = sidebarHTML;
  }

  // Render Top Navigation Bar
  const navbarContainer = document.getElementById('navbar-container');
  if (navbarContainer) {
    const initials = user.name
      .split(' ')
      .map(n => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();

    navbarContainer.innerHTML = `
      <header class="top-navbar">
        <button class="menu-toggle" id="menu-toggle-btn">☰</button>
        <div style="font-weight: 700; font-size: 16px; color: var(--text-muted);">
          Hostel Room Allocation Management System
        </div>
        <div class="user-profile-badge">
          <div class="user-avatar">${initials}</div>
          <div class="user-info">
            <span class="user-name">${user.name}</span>
            <span class="user-role">${user.role === 'admin' ? 'Administrator' : 'Student'}</span>
          </div>
        </div>
      </header>
    `;
  }

  // Bind UI control events
  bindShellEvents();
}

function bindShellEvents() {
  // Logout Button Event
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      clearSession();
      showToast('Logged out successfully. Redirecting...', 'success');
      setTimeout(() => {
        window.location.href = 'login.html';
      }, 1000);
    });
  }

  // Mobile sidebar toggle
  const toggleBtn = document.getElementById('menu-toggle-btn');
  const sidebar = document.getElementById('sidebar');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      sidebar.classList.toggle('open');
    });

    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && e.target !== toggleBtn) {
        sidebar.classList.remove('open');
      }
    });
  }
}
