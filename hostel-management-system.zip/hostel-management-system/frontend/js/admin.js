// Admin Dashboard Controller

document.addEventListener('DOMContentLoaded', () => {
  // Ensure user is admin
  requireAdmin();

  // Load Dashboard Data
  loadDashboardStats();
  loadRecentActivities();
});

async function loadDashboardStats() {
  try {
    const response = await apiRequest('/admin/dashboard-stats', 'GET');
    
    if (response.success && response.data) {
      const stats = response.data;
      
      // Update statistics card text
      document.getElementById('total-students-count').textContent = stats.totalStudents;
      document.getElementById('total-rooms-count').textContent = stats.totalRooms;
      document.getElementById('available-rooms-count').textContent = stats.availableRooms;
      document.getElementById('occupied-rooms-count').textContent = stats.occupiedRooms;
      document.getElementById('pending-allocations-count').textContent = stats.pendingAllocations;
      document.getElementById('pending-complaints-count').textContent = stats.pendingComplaints;

      // Update occupancy rate progress bar
      let occupancyRate = 0;
      if (stats.totalRooms > 0) {
        occupancyRate = Math.round((stats.occupiedRooms / stats.totalRooms) * 100);
      }
      
      const rateLabel = document.getElementById('occupancy-rate-label');
      const rateBar = document.getElementById('occupancy-rate-bar');
      
      if (rateLabel && rateBar) {
        rateLabel.textContent = `${occupancyRate}% Occupied`;
        rateBar.style.width = `${occupancyRate}%`;
      }
    }
  } catch (error) {
    showToast('Failed to load dashboard statistics', 'error');
    console.error(error);
  }
}

async function loadRecentActivities() {
  const activityList = document.getElementById('recent-activity-list');
  if (!activityList) return;

  activityList.innerHTML = '<li>Loading recent activities...</li>';

  try {
    // Retrieve recent allocations and complaints to form a unified feed
    const allocationsRes = await apiRequest('/allocations', 'GET');
    const complaintsRes = await apiRequest('/complaints', 'GET');

    const activities = [];

    // Format Allocations into activity feeds
    if (allocationsRes.success && allocationsRes.data) {
      allocationsRes.data.slice(0, 5).forEach(alloc => {
        let actionMsg = '';
        let badgeType = 'info';
        
        if (alloc.status === 'Pending') {
          actionMsg = `applied for Room ${alloc.room_number}`;
          badgeType = 'warning';
        } else if (alloc.status === 'Approved') {
          actionMsg = `allocated to Room ${alloc.room_number} (Bed ${alloc.bed_number})`;
          badgeType = 'success';
        } else if (alloc.status === 'Rejected') {
          actionMsg = `allocation request for Room ${alloc.room_number} rejected`;
          badgeType = 'danger';
        } else if (alloc.status === 'Vacated') {
          actionMsg = `vacated Room ${alloc.room_number}`;
          badgeType = 'danger';
        }

        activities.push({
          title: alloc.student_name,
          desc: actionMsg,
          time: new Date(alloc.updated_at || alloc.created_at),
          badgeText: `Allocation: ${alloc.status}`,
          badgeClass: `badge-${badgeType}`
        });
      });
    }

    // Format Complaints into activity feeds
    if (complaintsRes.success && complaintsRes.data) {
      complaintsRes.data.slice(0, 5).forEach(comp => {
        let badgeType = 'info';
        if (comp.status === 'Pending') badgeType = 'warning';
        else if (comp.status === 'In Progress') badgeType = 'info';
        else if (comp.status === 'Resolved') badgeType = 'success';
        else if (comp.status === 'Rejected') badgeType = 'danger';

        activities.push({
          title: `${comp.student_name} (${comp.category})`,
          desc: `filed complaint: "${comp.title}"`,
          time: new Date(comp.updated_at || comp.created_at),
          badgeText: `Complaint: ${comp.status}`,
          badgeClass: `badge-${badgeType}`
        });
      });
    }

    // Sort by timestamp descending
    activities.sort((a, b) => b.time - a.time);

    // Render list
    if (activities.length === 0) {
      activityList.innerHTML = '<li class="activity-item">No recent activity.</li>';
      return;
    }

    activityList.innerHTML = '';
    activities.slice(0, 6).forEach(act => {
      const formattedTime = act.time.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      const li = document.createElement('li');
      li.className = 'activity-item';
      li.innerHTML = `
        <div class="activity-meta">
          <span class="activity-title">${act.title}</span>
          <span class="activity-desc">${act.desc}</span>
          <span class="activity-time">⏰ ${formattedTime}</span>
        </div>
        <span class="badge ${act.badgeClass}">${act.badgeText}</span>
      `;
      activityList.appendChild(li);
    });

  } catch (error) {
    activityList.innerHTML = '<li class="activity-item" style="color: var(--color-danger);">Failed to load activities.</li>';
    console.error(error);
  }
}
