// Complaint Management Page Controller

let complaintsData = [];

document.addEventListener('DOMContentLoaded', () => {
  requireAuth();

  const user = getUser();
  
  // Conditionally display Admin vs Student UI actions
  const studentActionBtn = document.getElementById('student-action-btn');
  const adminFilters = document.getElementById('admin-filters');
  
  if (user.role === 'admin') {
    if (studentActionBtn) studentActionBtn.style.display = 'none';
    if (adminFilters) adminFilters.style.display = 'flex';
  } else {
    if (studentActionBtn) studentActionBtn.style.display = 'block';
    if (adminFilters) adminFilters.style.display = 'none';
  }

  // Load Complaints List
  loadComplaints();

  // Search/Filters Events
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', applySearchFilters);
  }

  const filterStatus = document.getElementById('filter-status');
  if (filterStatus) {
    filterStatus.addEventListener('change', applySearchFilters);
  }

  const filterCategory = document.getElementById('filter-category');
  if (filterCategory) {
    filterCategory.addEventListener('change', applySearchFilters);
  }

  // Modal Submit Setup
  setupModals();
});

// Load complaints list
async function loadComplaints() {
  const tableBody = document.getElementById('complaints-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading complaints...</td></tr>';

  try {
    const res = await apiRequest('/complaints', 'GET');
    if (res.success && res.data) {
      complaintsData = res.data;
      renderComplaints(complaintsData);
    }
  } catch (error) {
    showToast('Failed to load complaints', 'error');
    tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--color-danger);">Failed to load complaints list.</td></tr>';
  }
}

// Render complaints table
function renderComplaints(complaints) {
  const tableBody = document.getElementById('complaints-table-body');
  if (!tableBody) return;

  if (complaints.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No complaints logged.</td></tr>';
    return;
  }

  const user = getUser();
  tableBody.innerHTML = '';
  
  complaints.forEach(comp => {
    const tr = document.createElement('tr');
    
    let statusClass = 'badge-warning';
    if (comp.status === 'In Progress') statusClass = 'badge-info';
    else if (comp.status === 'Resolved') statusClass = 'badge-success';
    else if (comp.status === 'Rejected') statusClass = 'badge-danger';

    // Format dates
    const createdDate = new Date(comp.created_at).toLocaleDateString(undefined, {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    let actionBtn = '';
    if (user.role === 'admin') {
      actionBtn = `<button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px;" onclick="openRespondModal(${comp.id})">💬 Respond</button>`;
    } else {
      actionBtn = `<button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px;" onclick="viewComplaintDetail(${comp.id})">👁️ View</button>`;
    }

    tr.innerHTML = `
      <td><strong>#${comp.id}</strong></td>
      ${user.role === 'admin' ? `<td>${comp.student_name} (${comp.student_roll_no})</td>` : ''}
      <td>${comp.category}</td>
      <td><strong>${comp.title}</strong></td>
      <td>${createdDate}</td>
      <td><span class="badge ${statusClass}">${comp.status}</span></td>
      <td>${actionBtn}</td>
    `;
    tableBody.appendChild(tr);
  });
}

// Search and filters client-side
function applySearchFilters() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const status = document.getElementById('filter-status').value;
  const category = document.getElementById('filter-category').value;
  const user = getUser();

  const filtered = complaintsData.filter(comp => {
    const matchesQuery = 
      comp.title.toLowerCase().includes(query) ||
      comp.description.toLowerCase().includes(query) ||
      (user.role === 'admin' && comp.student_name.toLowerCase().includes(query));

    const matchesStatus = !status || comp.status === status;
    const matchesCategory = !category || comp.category === category;

    return matchesQuery && matchesStatus && matchesCategory;
  });

  renderComplaints(filtered);
}

// Modals Handler
function setupModals() {
  // New Complaint (Student Only)
  const addForm = document.getElementById('new-complaint-form');
  if (addForm) {
    addForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const payload = {
        category: document.getElementById('complaint-category').value,
        title: document.getElementById('complaint-title').value.trim(),
        description: document.getElementById('complaint-desc').value.trim()
      };

      if (!payload.category || !payload.title || !payload.description) {
        showToast('All fields are required', 'warning');
        return;
      }

      try {
        const res = await apiRequest('/complaints', 'POST', payload);
        if (res.success) {
          showToast('Complaint submitted successfully', 'success');
          closeModal('complaint-modal');
          addForm.reset();
          loadComplaints();
        }
      } catch (error) {
        showToast(error.message || 'Failed to submit complaint', 'error');
      }
    });
  }

  // Response Submit (Admin Only)
  const respondForm = document.getElementById('respond-complaint-form');
  if (respondForm) {
    respondForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const compId = document.getElementById('respond-comp-id').value;
      const payload = {
        status: document.getElementById('respond-status').value,
        response: document.getElementById('respond-feedback').value.trim()
      };

      try {
        const res = await apiRequest(`/complaints/${compId}`, 'PUT', payload);
        if (res.success) {
          showToast('Complaint response logged successfully', 'success');
          closeModal('respond-modal');
          respondForm.reset();
          loadComplaints();
        }
      } catch (error) {
        showToast(error.message || 'Failed to log complaint response', 'error');
      }
    });
  }
}

// Modal helper controls
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'flex';
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}

// Respond Modal details loader (Admin)
function openRespondModal(id) {
  const comp = complaintsData.find(c => c.id === id);
  if (!comp) return;

  document.getElementById('respond-comp-id').value = comp.id;
  document.getElementById('respond-title').textContent = comp.title;
  document.getElementById('respond-desc').textContent = comp.description;
  document.getElementById('respond-status').value = comp.status;
  document.getElementById('respond-feedback').value = comp.response || '';

  openModal('respond-modal');
}

// View Modal details loader (Student)
function viewComplaintDetail(id) {
  const comp = complaintsData.find(c => c.id === id);
  if (!comp) return;

  document.getElementById('view-comp-title').textContent = comp.title;
  document.getElementById('view-comp-cat').textContent = comp.category;
  document.getElementById('view-comp-desc').textContent = comp.description;
  
  const statusClass = comp.status === 'Resolved' ? 'badge-success' : (comp.status === 'Pending' ? 'badge-warning' : 'badge-danger');
  document.getElementById('view-comp-status').innerHTML = `<span class="badge ${statusClass}">${comp.status}</span>`;
  
  document.getElementById('view-comp-response').textContent = comp.response || 'No administrative response yet.';

  openModal('view-detail-modal');
}
