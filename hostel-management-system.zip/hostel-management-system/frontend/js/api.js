// API Connection and Authentication Helper

const API_BASE = 'http://localhost:5000/api';

// Token and Session Management
function getToken() {
  return localStorage.getItem('hms_token');
}

function getUser() {
  const user = localStorage.getItem('hms_user');
  return user ? JSON.parse(user) : null;
}

function saveSession(token, user) {
  localStorage.setItem('hms_token', token);
  localStorage.setItem('hms_user', JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem('hms_token');
  localStorage.removeItem('hms_user');
}

// Global API Request Wrapper
async function apiRequest(endpoint, method = 'GET', data = null) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json'
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config = {
    method,
    headers
  };

  if (data && (method === 'POST' || method === 'PUT')) {
    config.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, config);
    const result = await response.json();
    
    if (!response.ok) {
      throw new Error(result.message || 'API request failed');
    }
    
    return result;
  } catch (error) {
    console.error(`API Error [${method} ${endpoint}]:`, error.message);
    throw error;
  }
}

// Router Guards
function requireAuth() {
  const token = getToken();
  const user = getUser();
  if (!token || !user) {
    clearSession();
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

function requireAdmin() {
  const authenticated = requireAuth();
  if (!authenticated) return;
  
  const user = getUser();
  if (user.role !== 'admin') {
    showToast('Access denied. Redirecting to student portal.', 'error');
    setTimeout(() => {
      window.location.href = 'student.html';
    }, 1500);
    return false;
  }
  return true;
}

function requireStudent() {
  const authenticated = requireAuth();
  if (!authenticated) return;
  
  const user = getUser();
  if (user.role !== 'student') {
    showToast('Access denied. Redirecting to admin portal.', 'error');
    setTimeout(() => {
      window.location.href = 'admin.html';
    }, 1500);
    return false;
  }
  return true;
}

// Global Toast Notifications System
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  // Custom icons based on toast type
  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'error') icon = '❌';
  if (type === 'warning') icon = '⚠️';

  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  // Auto remove toast
  setTimeout(() => {
    toast.style.animation = 'toastIn 0.3s ease reverse forwards';
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 4000);
}
