// Interactive controllers for Landing Page
document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  initScrollAnimations();
  initFaqAccordion();
  initStatsCounters();
});

// 1. Mobile Menu Controls
function initMobileMenu() {
  const menuBtn = document.getElementById('menu-toggle-btn');
  const navbarMenu = document.getElementById('navbar-menu');

  if (menuBtn && navbarMenu) {
    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      navbarMenu.classList.toggle('open');
      menuBtn.innerHTML = navbarMenu.classList.contains('open') ? '✕' : '☰';
    });

    document.addEventListener('click', (e) => {
      if (navbarMenu.classList.contains('open') && !navbarMenu.contains(e.target) && e.target !== menuBtn) {
        navbarMenu.classList.remove('open');
        menuBtn.innerHTML = '☰';
      }
    });
  }
}

// 2. Scroll Animation Observer
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll('.scroll-fade');
  
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          observer.unobserve(entry.target); // Run animation once
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(el => observer.observe(el));
  } else {
    // Fallback if browser doesn't support IntersectionObserver
    animatedElements.forEach(el => el.classList.add('active'));
  }
}

// 3. FAQ Accordion logic
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question');
    const answerPanel = item.querySelector('.faq-answer');

    if (questionBtn && answerPanel) {
      questionBtn.addEventListener('click', () => {
        const isActive = item.classList.contains('active');

        // Collapse all other accordion items first
        faqItems.forEach(otherItem => {
          if (otherItem !== item && otherItem.classList.contains('active')) {
            otherItem.classList.remove('active');
            otherItem.querySelector('.faq-answer').style.maxHeight = '0';
          }
        });

        // Toggle current item
        if (isActive) {
          item.classList.remove('active');
          answerPanel.style.maxHeight = '0';
        } else {
          item.classList.add('active');
          answerPanel.style.maxHeight = answerPanel.scrollHeight + 'px';
        }
      });
    }
  });
}

// 4. Statistics Counters Animation
function initStatsCounters() {
  const statsSection = document.querySelector('.stats-section');
  const counterElements = document.querySelectorAll('.stat-number');

  if (!statsSection || counterElements.length === 0) return;

  const runCounter = (el) => {
    const target = parseInt(el.getAttribute('data-target'));
    const duration = 2000; // 2 seconds animation
    const stepTime = 30;
    const totalSteps = Math.ceil(duration / stepTime);
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      const val = Math.ceil((target / totalSteps) * currentStep);
      
      if (currentStep >= totalSteps) {
        el.textContent = target + (el.getAttribute('data-suffix') || '');
        clearInterval(timer);
      } else {
        el.textContent = val + (el.getAttribute('data-suffix') || '');
      }
    }, stepTime);
  };

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          counterElements.forEach(el => runCounter(el));
          observer.unobserve(statsSection); // Run counters once
        }
      });
    }, {
      threshold: 0.2
    });

    observer.observe(statsSection);
  } else {
    // Fallback: load directly if no observer support
    counterElements.forEach(el => {
      el.textContent = el.getAttribute('data-target') + (el.getAttribute('data-suffix') || '');
    });
  }
}