document.addEventListener('DOMContentLoaded', () => {
  fetchPendingRequests();
});

// Switch Tabs
function switchAllocationTab(tab) {
  // Hide all sections
  document.querySelectorAll('.allocation-sec').forEach(sec => {
    sec.classList.remove('active');
    sec.style.display = 'none';
  });
  
  // Deactivate all tabs
  document.querySelectorAll('.login-tab').forEach(t => {
    t.classList.remove('active');
  });

  // Activate chosen tab & section
  const activeTab = document.getElementById(`tab-${tab}`);
  const activeSec = document.getElementById(`sec-${tab}`);
  
  if (activeTab && activeSec) {
    activeTab.classList.add('active');
    activeSec.classList.add('active');
    activeSec.style.display = tab === 'manual' ? 'flex' : 'block';
  }

  // Load data based on tab
  if (tab === 'requests') {
    fetchPendingRequests();
  } else if (tab === 'active') {
    fetchActiveAllocations();
  } else if (tab === 'manual') {
    loadManualDropdowns();
  }
}

// Fetch Pending Allocation Requests
async function fetchPendingRequests() {
  const tbody = document.getElementById('pending-table-body');
  if (!tbody) return;

  try {
    const response = await apiCall('/allocations?status=Pending');
    if (response.success) {
      const list = response.data;
      tbody.innerHTML = '';

      if (list.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="8" style="text-align: center; padding: 30px; color: var(--text-secondary);">
              <i class="fas fa-key" style="font-size: 1.5rem; margin-bottom: 8px; display: block; color: var(--text-muted);"></i>
              No pending room allocation applications.
            </td>
          </tr>
        `;
        return;
      }

      list.forEach(item => {
        const date = new Date(item.allocation_date).toLocaleDateString();
        const row = document.createElement('tr');
        row.innerHTML = `
          <td><strong>${item.student_card_id}</strong></td>
          <td>${item.student_name}</td>
          <td>${item.gender}</td>
          <td>
            <div style="font-weight:500;">${item.course}</div>
            <div style="font-size:0.75rem; color:var(--text-secondary);">${item.department}</div>
          </td>
          <td><strong>Room ${item.room_number}</strong> (Block ${item.block})</td>
          <td>${item.room_type}</td>
          <td>${date}</td>
          <td style="text-align: right;">
            <div style="display: flex; justify-content: flex-end; gap: 8px;">
              <button class="btn btn-success btn-icon" onclick="openApproveModal(${item.id}, ${item.room_id}, '${item.student_name}', '${item.room_number}')" title="Approve Request">
                <i class="fas fa-check"></i> Approve
              </button>
              <button class="btn btn-danger btn-icon" onclick="rejectRequest(${item.id}, '${item.student_name}')" title="Reject Request">
                <i class="fas fa-times"></i> Reject
              </button>
            </div>
          </td>
        `;
        tbody.appendChild(row);
      });
    } else {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger);">${response.message}</td></tr>`;
    }
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger);">Failed to fetch request logs.</td></tr>`;
  }
}

// Fetch Active Approved Allocations
async function fetchActiveAllocations() {
  const tbody = document.getElementById('active-table-body');
  if (!tbody) return;

  const search = document.getElementById('search-active-allocations').value.trim();
  let query = '/allocations?status=Approved';
  if (search) {
    query += `&search=${encodeURIComponent(search)}`;
  }

  try {
    const response = await apiCall(query);
    if (response.success) {
      const list = response.data;
      tbody.innerHTML = '';

      if (list.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="8" style="text-align: center; padding: 30px; color: var(--text-secondary);">
              No active bed allocations found.
            </td>
          </tr>
        `;
        return;
      }

      list.forEach(item => {
        const date = new Date(item.allocation_date).toLocaleDateString();
        const row = document.createElement('tr');
        row.innerHTML = `
          <td><strong>Room ${item.room_number}</strong></td>
          <td><span class="badge badge-info">Bed ${item.bed_number}</span></td>
          <td>Block ${item.block}</td>
          <td>${item.student_card_id}</td>
          <td><strong>${item.student_name}</strong></td>
          <td>${item.gender}</td>
          <td>${date}</td>
          <td style="text-align: right;">
            <button class="btn btn-danger btn-icon" onclick="vacateRoom(${item.id}, '${item.student_name}', '${item.room_number}')" title="Vacate Room">
              <i class="fas fa-door-open"></i> Vacate Student
            </button>
          </td>
        `;
        tbody.appendChild(row);
      });
    } else {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger);">${response.message}</td></tr>`;
    }
  } catch (error) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger);">Failed to fetch active allocations.</td></tr>`;
  }
}

// Global lists cache
let cachedRooms = [];
let cachedStudents = [];

// Load Dropdowns for Manual and Transfer Form
async function loadManualDropdowns() {
  const selectStudent = document.getElementById('manual-student');
  const selectRoomManual = document.getElementById('manual-room');
  const selectStudentTransfer = document.getElementById('transfer-student');
  const selectRoomTransfer = document.getElementById('transfer-room');

  selectStudent.innerHTML = '<option value="">Loading...</option>';
  selectRoomManual.innerHTML = '<option value="">Loading...</option>';
  selectStudentTransfer.innerHTML = '<option value="">Loading...</option>';
  selectRoomTransfer.innerHTML = '<option value="">Loading...</option>';

  try {
    const studentsRes = await apiCall('/students');
    const roomsRes = await apiCall('/rooms');

    if (studentsRes.success && roomsRes.success) {
      cachedStudents = studentsRes.data;
      cachedRooms = roomsRes.data;

      // Filter unallocated students for Direct Allocation
      const unallocated = cachedStudents.filter(s => s.status === 'Active' && !s.room_number);
      selectStudent.innerHTML = '<option value="">-- Choose Student --</option>';
      unallocated.forEach(s => {
        selectStudent.innerHTML += `<option value="${s.id}">${s.name} (${s.student_id}) - ${s.gender}</option>`;
      });

      // Filter allocated students for Room Transfer
      const allocated = cachedStudents.filter(s => s.status === 'Active' && s.room_number);
      selectStudentTransfer.innerHTML = '<option value="">-- Choose Student --</option>';
      allocated.forEach(s => {
        selectStudentTransfer.innerHTML += `<option value="${s.id}">${s.name} (${s.student_id})</option>`;
      });

      // Filter rooms with capacity for Direct Allocation
      selectRoomManual.innerHTML = '<option value="">-- Choose Room --</option>';
      cachedRooms.forEach(r => {
        if (r.status !== 'Maintenance' && r.available_beds > 0) {
          selectRoomManual.innerHTML += `<option value="${r.id}">Room ${r.room_number} (Block ${r.block}, ${r.room_type}, ${r.available_beds} beds free) - ${r.gender_type}s</option>`;
        }
      });

      // Rooms for Transfer (includes all available rooms)
      selectRoomTransfer.innerHTML = '<option value="">-- Choose New Room --</option>';
      cachedRooms.forEach(r => {
        if (r.status !== 'Maintenance' && r.available_beds > 0) {
          selectRoomTransfer.innerHTML += `<option value="${r.id}">Room ${r.room_number} (Block ${r.block}, ${r.room_type}, ${r.available_beds} beds free) - ${r.gender_type}s</option>`;
        }
      });

    } else {
      showToast('Error loading forms options.', 'error');
    }
  } catch (error) {
    showToast('Failed to populate student/room dropdown lists.', 'error');
  }
}

// When transfer student is selected, update label details
function handleTransferStudentChange() {
  const studentId = document.getElementById('transfer-student').value;
  const label = document.getElementById('transfer-current-room-text');

  if (!studentId) {
    label.textContent = '';
    return;
  }

  const student = cachedStudents.find(s => s.id == studentId);
  if (student && student.room_number) {
    label.textContent = `Currently allocated to: Room ${student.room_number} (Bed ${student.bed_number})`;
  } else {
    label.textContent = '';
  }
}

// Populate Bed number selection depending on free beds in selected room
async function handleRoomSelectChange(prefix) {
  const roomId = document.getElementById(`${prefix}-room`).value;
  const bedSelect = document.getElementById(`${prefix}-bed`);

  bedSelect.innerHTML = '<option value="">-- Select Bed --</option>';
  if (!roomId) return;

  const room = cachedRooms.find(r => r.id == roomId);
  if (!room) return;

  // Let's determine which beds are taken. Fetch all active allocations for this room.
  try {
    // We can fetch from active allocations list
    const response = await apiCall('/allocations?status=Approved');
    const activeAllocations = response.success ? response.data : [];
    
    // Find taken bed numbers in this room
    const takenBeds = activeAllocations
      .filter(a => a.room_id == roomId)
      .map(a => parseInt(a.bed_number, 10));

    // Determine max beds
    let maxBeds = 1;
    if (room.room_type === 'Double') maxBeds = 2;
    if (room.room_type === 'Triple') maxBeds = 3;
    if (room.room_type === 'Four Sharing') maxBeds = 4;

    // Build options
    let addedAny = false;
    for (let i = 1; i <= maxBeds; i++) {
      if (!takenBeds.includes(i)) {
        bedSelect.innerHTML += `<option value="${i}">Bed ${i}</option>`;
        addedAny = true;
      }
    }
    
    if (!addedAny) {
      bedSelect.innerHTML = '<option value="">No beds available in this room.</option>';
    }
  } catch (error) {
    showToast('Error checking bed positions availability.', 'error');
  }
}

// Open Approval Modal
async function openApproveModal(allocationId, roomId, studentName, roomNo) {
  const modal = document.getElementById('approve-modal');
  const details = document.getElementById('approve-details-text');
  const bedSelect = document.getElementById('approve-bed-number');
  
  document.getElementById('approve-allocation-id').value = allocationId;
  document.getElementById('approve-room-id').value = roomId;
  details.textContent = `Assign a bed number for ${studentName} in Room ${roomNo}.`;

  bedSelect.innerHTML = '<option value="">Loading beds...</option>';
  modal.classList.add('active');

  try {
    const roomResponse = await apiCall(`/rooms/${roomId}`);
    if (roomResponse.success) {
      const room = roomResponse.data;
      
      // Fetch taken beds
      const response = await apiCall('/allocations?status=Approved');
      const activeAllocations = response.success ? response.data : [];
      const takenBeds = activeAllocations
        .filter(a => a.room_id == roomId)
        .map(a => parseInt(a.bed_number, 10));

      let maxBeds = 1;
      if (room.room_type === 'Double') maxBeds = 2;
      if (room.room_type === 'Triple') maxBeds = 3;
      if (room.room_type === 'Four Sharing') maxBeds = 4;

      bedSelect.innerHTML = '<option value="">-- Choose Bed --</option>';
      for (let i = 1; i <= maxBeds; i++) {
        if (!takenBeds.includes(i)) {
          bedSelect.innerHTML += `<option value="${i}">Bed ${i}</option>`;
        }
      }
    } else {
      bedSelect.innerHTML = '<option value="">Failed to read room capacity.</option>';
    }
  } catch (error) {
    bedSelect.innerHTML = '<option value="">Error fetching room details.</option>';
  }
}

// Close Approve Modal
function closeApproveModal() {
  document.getElementById('approve-modal').classList.remove('active');
}

// Submit Approve Request
async function submitApproveRequest(e) {
  e.preventDefault();
  const allocationId = document.getElementById('approve-allocation-id').value;
  const bed_number = parseInt(document.getElementById('approve-bed-number').value, 10);

  try {
    const response = await apiCall(`/allocations/${allocationId}/approve`, 'PUT', { bed_number });
    if (response.success) {
      showToast('Allocation approved successfully!', 'success');
      closeApproveModal();
      fetchPendingRequests();
    } else {
      showToast(response.message || 'Failed to approve request', 'error');
    }
  } catch (error) {
    showToast('Connection error.', 'error');
  }
}

// Reject Request
async function rejectRequest(id, studentName) {
  if (confirm(`Are you sure you want to REJECT the room request from "${studentName}"?`)) {
    try {
      const response = await apiCall(`/allocations/${id}/reject`, 'PUT');
      if (response.success) {
        showToast('Request rejected.', 'warning');
        fetchPendingRequests();
      } else {
        showToast(response.message || 'Error rejecting request', 'error');
      }
    } catch (error) {
      showToast('Connection error.', 'error');
    }
  }
}

// Vacate Room
async function vacateRoom(id, studentName, roomNo) {
  if (confirm(`Are you sure you want to vacate "${studentName}" from Room ${roomNo}? This bed will become immediately available for allocation.`)) {
    try {
      const response = await apiCall(`/allocations/${id}/vacate`, 'PUT');
      if (response.success) {
        showToast('Room vacated successfully.', 'success');
        fetchActiveAllocations();
      } else {
        showToast(response.message || 'Error vacating room', 'error');
      }
    } catch (error) {
      showToast('Connection error.', 'error');
    }
  }
}

// Submit Manual Direct Allocation Form
async function submitManualAllocation(e) {
  e.preventDefault();
  const student_id = document.getElementById('manual-student').value;
  const room_id = document.getElementById('manual-room').value;
  const bed_number = parseInt(document.getElementById('manual-bed').value, 10);

  try {
    const response = await apiCall('/allocations', 'POST', {
      student_id: parseInt(student_id, 10),
      room_id: parseInt(room_id, 10),
      bed_number
    });

    if (response.success) {
      showToast('Direct allocation created successfully.', 'success');
      document.getElementById('form-manual-allocation').reset();
      document.getElementById('manual-bed').innerHTML = '<option value="">Select Room First</option>';
      loadManualDropdowns();
    } else {
      showToast(response.message || 'Failed to allocate room.', 'error');
    }
  } catch (error) {
    showToast('Connection error.', 'error');
  }
}

// Submit Transfer Room Form
async function submitTransferAllocation(e) {
  e.preventDefault();
  const student_id = document.getElementById('transfer-student').value;
  const new_room_id = document.getElementById('transfer-room').value;
  const new_bed_number = parseInt(document.getElementById('transfer-bed').value, 10);

  try {
    const response = await apiCall('/allocations/transfer', 'PUT', {
      student_id: parseInt(student_id, 10),
      new_room_id: parseInt(new_room_id, 10),
      new_bed_number
    });

    if (response.success) {
      showToast('Student room transfer complete.', 'success');
      document.getElementById('form-transfer-allocation').reset();
      document.getElementById('transfer-bed').innerHTML = '<option value="">Select Room First</option>';
      document.getElementById('transfer-current-room-text').textContent = '';
      loadManualDropdowns();
    } else {
      showToast(response.message || 'Failed to transfer student.', 'error');
    }
  } catch (error) {
    showToast('Connection error.', 'error');
  }
}
