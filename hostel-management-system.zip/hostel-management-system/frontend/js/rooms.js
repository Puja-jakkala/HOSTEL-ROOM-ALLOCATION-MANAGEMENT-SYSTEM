// Room Management Page Controller

let roomsData = [];

document.addEventListener('DOMContentLoaded', () => {
  requireAdmin();

  // Load Rooms List
  loadRooms();

  // Search/Filters Events
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', applySearchFilters);
  }

  const filterBlock = document.getElementById('filter-block');
  if (filterBlock) {
    filterBlock.addEventListener('change', applySearchFilters);
  }

  const filterType = document.getElementById('filter-type');
  if (filterType) {
    filterType.addEventListener('change', applySearchFilters);
  }

  const filterStatus = document.getElementById('filter-status');
  if (filterStatus) {
    filterStatus.addEventListener('change', applySearchFilters);
  }

  // Modals Submit Setup
  setupModals();
});

// Fetch all rooms
async function loadRooms() {
  const tableBody = document.getElementById('rooms-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">Loading rooms...</td></tr>';

  try {
    const response = await apiRequest('/rooms', 'GET');
    if (response.success && response.data) {
      roomsData = response.data;
      renderRooms(roomsData);
    }
  } catch (error) {
    showToast('Failed to load rooms list', 'error');
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--color-danger);">Failed to load rooms.</td></tr>';
  }
}

// Render Room rows
function renderRooms(rooms) {
  const tableBody = document.getElementById('rooms-table-body');
  if (!tableBody) return;

  if (rooms.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No rooms found.</td></tr>';
    return;
  }

  tableBody.innerHTML = '';
  rooms.forEach(room => {
    const tr = document.createElement('tr');
    
    let statusClass = 'badge-success';
    if (room.status === 'Partially Occupied') statusClass = 'badge-info';
    else if (room.status === 'Full') statusClass = 'badge-warning';
    else if (room.status === 'Maintenance') statusClass = 'badge-danger';
    
    tr.innerHTML = `
      <td><strong>${room.room_number}</strong></td>
      <td>${room.block}</td>
      <td>Floor ${room.floor}</td>
      <td>${room.room_type}</td>
      <td>${room.occupied_beds} / ${room.capacity}</td>
      <td>${room.available_beds} beds</td>
      <td><span class="badge ${statusClass}">${room.status}</span></td>
      <td>
        <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px; color: var(--color-primary);" onclick="openEditRoomModal(${room.id})">✏️ Edit</button>
        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="confirmDeleteRoom(${room.id}, '${room.room_number}')">🗑️ Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

// Filter and Search
function applySearchFilters() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const block = document.getElementById('filter-block').value;
  const type = document.getElementById('filter-type').value;
  const status = document.getElementById('filter-status').value;

  const filtered = roomsData.filter(room => {
    const matchesQuery = 
      room.room_number.toLowerCase().includes(query) ||
      room.block.toLowerCase().includes(query);

    const matchesBlock = !block || room.block === block;
    const matchesType = !type || room.room_type === type;
    const matchesStatus = !status || room.status === status;

    return matchesQuery && matchesBlock && matchesType && matchesStatus;
  });

  renderRooms(filtered);
}

// Setup Room Modals
function setupModals() {
  // Add Room Submit
  const addForm = document.getElementById('add-room-form');
  if (addForm) {
    addForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const payload = {
        room_number: document.getElementById('add-room-number').value.trim(),
        block: document.getElementById('add-block').value.trim(),
        floor: document.getElementById('add-floor').value,
        room_type: document.getElementById('add-type').value,
        capacity: document.getElementById('add-capacity').value,
        gender_type: document.getElementById('add-gender').value,
        status: document.getElementById('add-status').value
      };

      try {
        const response = await apiRequest('/rooms', 'POST', payload);
        if (response.success) {
          showToast('Room created successfully', 'success');
          closeModal('add-room-modal');
          addForm.reset();
          loadRooms();
        }
      } catch (error) {
        showToast(error.message || 'Failed to create room', 'error');
      }
    });
  }

  // Edit Room Submit
  const editForm = document.getElementById('edit-room-form');
  if (editForm) {
    editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const roomId = document.getElementById('edit-room-id').value;

      const payload = {
        room_number: document.getElementById('edit-room-number').value.trim(),
        block: document.getElementById('edit-block').value.trim(),
        floor: document.getElementById('edit-floor').value,
        room_type: document.getElementById('edit-type').value,
        capacity: document.getElementById('edit-capacity').value,
        gender_type: document.getElementById('edit-gender').value,
        status: document.getElementById('edit-status').value
      };

      try {
        const response = await apiRequest(`/rooms/${roomId}`, 'PUT', payload);
        if (response.success) {
          showToast('Room updated successfully', 'success');
          closeModal('edit-room-modal');
          loadRooms();
        }
      } catch (error) {
        showToast(error.message || 'Failed to update room', 'error');
      }
    });
  }
}

// Modal helper controls
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'flex';
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}

// Open Edit Modal with Room details
async function openEditRoomModal(id) {
  // Find room locally from array to avoid redundant API request (or do API fetch)
  const room = roomsData.find(r => r.id === id);
  if (!room) return;

  document.getElementById('edit-room-id').value = room.id;
  document.getElementById('edit-room-number').value = room.room_number;
  document.getElementById('edit-block').value = room.block;
  document.getElementById('edit-floor').value = room.floor;
  document.getElementById('edit-type').value = room.room_type;
  document.getElementById('edit-capacity').value = room.capacity;
  document.getElementById('edit-gender').value = room.gender_type;
  document.getElementById('edit-status').value = room.status;

  openModal('edit-room-modal');
}

// Delete Confirmation
let pendingDeleteId = null;
function confirmDeleteRoom(id, roomNumber) {
  pendingDeleteId = id;
  document.getElementById('delete-room-number').textContent = roomNumber;
  openModal('delete-room-modal');
}

async function executeDeleteRoom() {
  if (!pendingDeleteId) return;

  try {
    const res = await apiRequest(`/rooms/${pendingDeleteId}`, 'DELETE');
    if (res.success) {
      showToast('Room deleted successfully', 'success');
      closeModal('delete-room-modal');
      loadRooms();
    }
  } catch (error) {
    showToast(error.message || 'Failed to delete room', 'error');
  } finally {
    pendingDeleteId = null;
  }
}
