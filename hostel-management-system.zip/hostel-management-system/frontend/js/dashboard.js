document.addEventListener('DOMContentLoaded', () => {
  // Check if we are on the admin dashboard page
  if (document.getElementById('stat-students')) {
    loadDashboardStats();
    loadRoomOccupancyWidget();
  }

  // Check if we are on the student portal page
  if (document.getElementById('student-portal-wrapper')) {
    initializeStudentPortal();
  }
});

/* ==========================================================================
   ADMIN DASHBOARD LOGIC
   ========================================================================== */

// Fetch and render dashboard metrics
async function loadDashboardStats() {
  try {
    const response = await apiCall('/admin/dashboard-stats');
    if (response.success) {
      const stats = response.data;
      document.getElementById('stat-students').textContent = stats.totalStudents;
      document.getElementById('stat-rooms').textContent = stats.totalRooms;
      document.getElementById('stat-available-rooms').textContent = stats.availableRooms;
      document.getElementById('stat-occupied-rooms').textContent = stats.occupiedRooms;
      document.getElementById('stat-pending-allocations').textContent = stats.pendingAllocations;
      document.getElementById('stat-pending-complaints').textContent = stats.pendingComplaints;
    } else {
      showToast(response.message || 'Failed to load stats', 'error');
    }
  } catch (error) {
    console.error('Error loading dashboard stats:', error);
    showToast('Could not fetch dashboard counters.', 'error');
  }
}

// Fetch all rooms, group by block, and render progress bars
async function loadRoomOccupancyWidget() {
  const barsContainer = document.getElementById('occupancy-bars');
  if (!barsContainer) return;

  try {
    const response = await apiCall('/rooms');
    if (response.success) {
      const rooms = response.data;
      
      if (rooms.length === 0) {
        barsContainer.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-door-open"></i>
            <p>No rooms registered yet.</p>
          </div>
        `;
        return;
      }

      // Group rooms by block
      const blockStats = {};
      rooms.forEach(room => {
        const block = room.block || 'Unknown';
        if (!blockStats[block]) {
          blockStats[block] = { capacity: 0, occupied: 0 };
        }
        blockStats[block].capacity += room.capacity;
        blockStats[block].occupied += room.occupied_beds;
      });

      // Clear loading state
      barsContainer.innerHTML = '';

      // Render progress bars for each block
      Object.keys(blockStats).sort().forEach(blockName => {
        const stats = blockStats[blockName];
        const percent = stats.capacity > 0 ? Math.round((stats.occupied / stats.capacity) * 100) : 0;
        
        const barWrapper = document.createElement('div');
        barWrapper.className = 'occupancy-bar-wrapper';
        barWrapper.innerHTML = `
          <div class="occupancy-label">
            <span><strong>Block ${blockName}</strong></span>
            <span>${stats.occupied} / ${stats.capacity} Beds Occupied (${percent}%)</span>
          </div>
          <div class="occupancy-progress">
            <div class="occupancy-fill" style="width: ${percent}%;"></div>
          </div>
        `;
        barsContainer.appendChild(barWrapper);
      });

    } else {
      barsContainer.innerHTML = '<p class="text-danger">Failed to fetch occupancy details.</p>';
    }
  } catch (error) {
    console.error('Error loading occupancy widget:', error);
    barsContainer.innerHTML = '<p class="text-danger">Error connecting to server.</p>';
  }
}


/* ==========================================================================
   STUDENT DASHBOARD LOGIC
   ========================================================================== */

let studentGender = '';

// Initialize student portal data
function initializeStudentPortal() {
  loadStudentProfileAndAllocation();
  fetchStudentPayments();
}

// Fetch student profile, load values into headers/cards and inspect allocations
async function loadStudentProfileAndAllocation() {
  const badge = document.getElementById('portal-allocation-badge');
  const infoArea = document.getElementById('portal-allocation-info');

  try {
    const response = await apiCall('/auth/me');
    if (response.success) {
      const user = response.data;
      const s = user.studentProfile;

      if (!s) {
        badge.innerHTML = '<span class="badge badge-danger">Profile Missing</span>';
        infoArea.innerHTML = '<p>Your student profile was not found. Please contact administration.</p>';
        return;
      }

      studentGender = s.gender;

      // Update student details
      document.getElementById('portal-student-id').textContent = `Card ID: ${s.student_id}`;
      document.getElementById('portal-course').textContent = s.course;
      document.getElementById('portal-dept').textContent = s.department;

      // Check allocation status
      const [allocResponse] = await apiCall('/allocations');
      const studentAllocations = allocResponse.success ? allocResponse.data : [];
      
      // Find any Approved or Pending allocation
      const activeAlloc = studentAllocations.find(a => a.status === 'Approved' || a.status === 'Pending');

      if (activeAlloc) {
        if (activeAlloc.status === 'Approved') {
          badge.innerHTML = '<span class="badge badge-success">Approved</span>';
          infoArea.innerHTML = `
            <div style="font-weight:600; font-size:0.95rem; margin-bottom: 4px;">Room ${activeAlloc.room_number}</div>
            <div style="font-size:0.8rem; color:var(--text-secondary);">Block ${activeAlloc.block}, Floor ${activeAlloc.floor} &bull; Bed ${activeAlloc.bed_number}</div>
            <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Allocated: ${new Date(activeAlloc.allocation_date).toLocaleDateString()}</div>
          `;

          // Hide application form and show they have a room
          document.getElementById('apply-room-widget').style.display = 'block';
          document.getElementById('form-room-apply').style.display = 'none';
          document.getElementById('application-status-area').style.display = 'block';
          document.getElementById('application-status-text').innerHTML = `
            <i class="fas fa-check-circle" style="color:var(--success); font-size:1.8rem; margin-bottom:8px; display:block;"></i>
            You are currently allocated to <strong>Room ${activeAlloc.room_number} (Bed ${activeAlloc.bed_number})</strong>.
          `;
        } else if (activeAlloc.status === 'Pending') {
          badge.innerHTML = '<span class="badge badge-warning">Pending Approval</span>';
          infoArea.innerHTML = `
            <div style="font-weight:600; font-size:0.95rem; margin-bottom: 4px;">Room ${activeAlloc.room_number}</div>
            <div style="font-size:0.8rem; color:var(--text-secondary);">Warden approval is required.</div>
          `;

          // Show pending status in application widget
          document.getElementById('apply-room-widget').style.display = 'block';
          document.getElementById('form-room-apply').style.display = 'none';
          document.getElementById('application-status-area').style.display = 'block';
          document.getElementById('application-status-text').innerHTML = `
            <i class="fas fa-hourglass-half" style="color:var(--warning); font-size:1.8rem; margin-bottom:8px; display:block;"></i>
            Your application for <strong>Room ${activeAlloc.room_number}</strong> is pending warden review.
          `;
        }
      } else {
        // No active allocations
        badge.innerHTML = '<span class="badge badge-danger">Not Allocated</span>';
        infoArea.innerHTML = '<p>You do not have any active room allocation. Please apply for a bed below.</p>';

        // Show application form
        document.getElementById('apply-room-widget').style.display = 'block';
        document.getElementById('form-room-apply').style.display = 'block';
        document.getElementById('application-status-area').style.display = 'none';

        // Load rooms compatible with gender and occupancy
        loadAvailableRoomsForApplication();
      }
    }
  } catch (error) {
    console.error('Error loading student dashboard details:', error);
    showToast('Failed to load profile details.', 'error');
  }
}

// Fetch available rooms matching student's gender policy
async function loadAvailableRoomsForApplication() {
  const select = document.getElementById('apply-room-select');
  if (!select) return;

  select.innerHTML = '<option value="">Loading rooms...</option>';

  try {
    const response = await apiCall('/rooms');
    if (response.success) {
      const rooms = response.data;
      select.innerHTML = '<option value="">-- Choose a Room --</option>';

      // Filter rooms: status is Available/Partially Occupied, capacity has free beds, matches gender
      const eligibleRooms = rooms.filter(r => 
        r.status !== 'Maintenance' && 
        r.available_beds > 0 &&
        (r.gender_type === 'Co-ed' || r.gender_type === studentGender)
      );

      if (eligibleRooms.length === 0) {
        select.innerHTML = '<option value="">No available rooms compatible with your gender</option>';
        return;
      }

      eligibleRooms.forEach(r => {
        select.innerHTML += `<option value="${r.id}">Room ${r.room_number} (Block ${r.block}, Floor ${r.floor}) - ${r.room_type} (${r.available_beds} beds left)</option>`;
      });
    } else {
      select.innerHTML = '<option value="">Failed to load available rooms.</option>';
    }
  } catch (error) {
    select.innerHTML = '<option value="">Error connecting to server.</option>';
  }
}

// Submit room application request
async function submitRoomApplication(e) {
  e.preventDefault();
  const room_id = document.getElementById('apply-room-select').value;
  if (!room_id) return;

  const btn = document.getElementById('btn-apply-submit');
  btn.disabled = true;

  try {
    const response = await apiCall('/allocations', 'POST', { room_id: parseInt(room_id, 10) });
    if (response.success) {
      showToast('Room allocation request submitted successfully.', 'success');
      loadStudentProfileAndAllocation();
    } else {
      showToast(response.message || 'Failed to submit application', 'error');
      btn.disabled = false;
    }
  } catch (error) {
    showToast('Connection error. Failed to send request.', 'error');
    btn.disabled = false;
  }
}

// Fetch payment transactions for student
async function fetchStudentPayments() {
  const tbody = document.getElementById('student-payments-body');
  if (!tbody) return;

  try {
    const response = await apiCall('/payments');
    if (response.success) {
      const payments = response.data;
      tbody.innerHTML = '';

      if (payments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted);">No payment records found.</td></tr>';
        return;
      }

      payments.forEach(p => {
        const date = new Date(p.payment_date).toLocaleDateString();
        
        let badge = '';
        if (p.payment_status === 'Paid') badge = '<span class="badge badge-success">Paid</span>';
        if (p.payment_status === 'Pending') badge = '<span class="badge badge-warning">Pending</span>';
        if (p.payment_status === 'Failed') badge = '<span class="badge badge-danger">Failed</span>';

        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${date}</td>
          <td><strong>$${parseFloat(p.amount).toFixed(2)}</strong></td>
          <td>${p.payment_method}</td>
          <td>${badge}</td>
        `;
        tbody.appendChild(row);
      });
    }
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--danger);">Error loading fees logs.</td></tr>';
  }
}

// Open Payment Modal
function openPaymentModal() {
  document.getElementById('payment-form').reset();
  document.getElementById('payment-modal').classList.add('active');
}

// Close Payment Modal
function closePaymentModal() {
  document.getElementById('payment-modal').classList.remove('active');
}

// Submit simulated fee payment
async function submitStudentPayment(e) {
  e.preventDefault();
  const amount = parseFloat(document.getElementById('pay-amount').value);
  const payment_method = document.getElementById('pay-method').value;
  const transaction_id = document.getElementById('pay-txn').value.trim();

  const btn = document.getElementById('btn-pay-submit');
  btn.disabled = true;

  try {
    const payload = { amount, payment_method };
    if (transaction_id) payload.transaction_id = transaction_id;

    const response = await apiCall('/payments', 'POST', payload);
    if (response.success) {
      showToast('Fee payment reported successfully!', 'success');
      closePaymentModal();
      fetchStudentPayments();
    } else {
      showToast(response.message || 'Failed to submit payment transaction', 'error');
    }
  } catch (error) {
    showToast('Failed to connect to backend server.', 'error');
  } finally {
    btn.disabled = false;
  }
}
