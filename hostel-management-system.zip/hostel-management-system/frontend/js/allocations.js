// Room Allocation Page Controller

let allocationsData = [];
let studentsList = [];
let roomsList = [];

document.addEventListener('DOMContentLoaded', () => {
  requireAdmin();

  // Load allocations list
  loadAllocations();

  // Search/Filters Events
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', applySearchFilters);
  }

  const filterStatus = document.getElementById('filter-status');
  if (filterStatus) {
    filterStatus.addEventListener('change', applySearchFilters);
  }

  // Pre-load students and rooms for the manual allocation modal
  loadDropdownData();

  // Modal setup
  setupModals();
});

// Load allocations
async function loadAllocations() {
  const tableBody = document.getElementById('allocations-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">Loading allocations...</td></tr>';

  try {
    const res = await apiRequest('/allocations', 'GET');
    if (res.success && res.data) {
      allocationsData = res.data;
      renderAllocations(allocationsData);
    }
  } catch (error) {
    showToast('Failed to load allocations list', 'error');
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--color-danger);">Failed to load allocations.</td></tr>';
  }
}

// Render allocations table
function renderAllocations(allocations) {
  const tableBody = document.getElementById('allocations-table-body');
  if (!tableBody) return;

  if (allocations.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No room allocations found.</td></tr>';
    return;
  }

  tableBody.innerHTML = '';
  allocations.forEach(alloc => {
    const tr = document.createElement('tr');
    
    let statusClass = 'badge-info';
    if (alloc.status === 'Pending') statusClass = 'badge-warning';
    else if (alloc.status === 'Approved') statusClass = 'badge-success';
    else if (alloc.status === 'Rejected' || alloc.status === 'Vacated') statusClass = 'badge-danger';

    // Format dates
    const allocDate = new Date(alloc.request_date || alloc.created_at).toLocaleDateString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric'
    });

    let actionButtons = '';
    if (alloc.status === 'Pending') {
      actionButtons = `
        <button class="btn btn-primary" style="padding: 4px 8px; font-size: 12px;" onclick="approveAllocation(${alloc.id})">👍 Approve</button>
        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="rejectAllocation(${alloc.id})">❌ Reject</button>
      `;
    } else if (alloc.status === 'Approved') {
      actionButtons = `
        <button class="btn btn-danger" style="padding: 4px 8px; font-size: 12px;" onclick="vacateAllocation(${alloc.id})">🚪 Vacate</button>
      `;
    } else {
      actionButtons = `<span style="font-size: 13px; color: var(--text-muted);">No action</span>`;
    }

    tr.innerHTML = `
      <td><strong>${alloc.student_roll_no}</strong></td>
      <td>${alloc.student_name}</td>
      <td>${alloc.student_gender}</td>
      <td>Room ${alloc.room_number} (${alloc.block})</td>
      <td>Bed ${alloc.bed_number}</td>
      <td>${allocDate}</td>
      <td><span class="badge ${statusClass}">${alloc.status}</span></td>
      <td>${actionButtons}</td>
    `;
    tableBody.appendChild(tr);
  });
}

// Fetch Dropdown List Data for manually assigning a student to a room
async function loadDropdownData() {
  try {
    // 1. Fetch Students
    const studentRes = await apiRequest('/students', 'GET');
    if (studentRes.success && studentRes.data) {
      studentsList = studentRes.data.filter(s => s.status === 'Active');
      const studentSelect = document.getElementById('alloc-student');
      if (studentSelect) {
        studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
        studentsList.forEach(s => {
          studentSelect.innerHTML += `<option value="${s.id}">${s.name} (${s.student_id} - ${s.gender})</option>`;
        });
      }
    }

    // 2. Fetch Rooms
    const roomRes = await apiRequest('/rooms', 'GET');
    if (roomRes.success && roomRes.data) {
      // Show available rooms
      roomsList = roomRes.data.filter(r => r.occupied_beds < r.capacity && r.status !== 'Maintenance');
      const roomSelect = document.getElementById('alloc-room');
      if (roomSelect) {
        roomSelect.innerHTML = '<option value="">-- Select Room --</option>';
        roomsList.forEach(r => {
          roomSelect.innerHTML += `<option value="${r.id}">${r.room_number} (${r.block} - ${r.room_type} - for ${r.gender_type}s)</option>`;
        });
      }
    }
  } catch (error) {
    console.error('Error preloading dropdown options:', error);
  }
}

// Search and Filter logic
function applySearchFilters() {
  const query = document.getElementById('search-input').value.toLowerCase().trim();
  const status = document.getElementById('filter-status').value;

  const filtered = allocationsData.filter(alloc => {
    const matchesQuery = 
      alloc.student_name.toLowerCase().includes(query) ||
      alloc.student_roll_no.toLowerCase().includes(query) ||
      alloc.room_number.toLowerCase().includes(query) ||
      alloc.block.toLowerCase().includes(query);

    const matchesStatus = !status || alloc.status === status;

    return matchesQuery && matchesStatus;
  });

  renderAllocations(filtered);
}

// Setup Allocation Modals
function setupModals() {
  const allocForm = document.getElementById('manual-allocation-form');
  if (allocForm) {
    allocForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const payload = {
        student_id: document.getElementById('alloc-student').value,
        room_id: document.getElementById('alloc-room').value,
        bed_number: document.getElementById('alloc-bed').value || '1',
        allocation_date: document.getElementById('alloc-date').value
      };

      if (!payload.student_id || !payload.room_id || !payload.allocation_date) {
        showToast('Please fill in all required fields.', 'warning');
        return;
      }

      try {
        const response = await apiRequest('/allocations', 'POST', payload);
        if (response.success) {
          showToast('Room successfully allocated to student', 'success');
          closeModal('alloc-modal');
          allocForm.reset();
          loadAllocations();
          loadDropdownData(); // reload dropdowns since capacity changes
        }
      } catch (error) {
        showToast(error.message || 'Failed to allocate room', 'error');
      }
    });
  }
}

// Action triggers
async function approveAllocation(id) {
  if (!confirm('Are you sure you want to APPROVE this allocation request?')) return;
  try {
    const res = await apiRequest(`/allocations/${id}/approve`, 'PUT');
    if (res.success) {
      showToast('Allocation approved successfully', 'success');
      loadAllocations();
      loadDropdownData();
    }
  } catch (error) {
    showToast(error.message || 'Failed to approve allocation', 'error');
  }
}

async function rejectAllocation(id) {
  if (!confirm('Are you sure you want to REJECT this allocation request?')) return;
  try {
    const res = await apiRequest(`/allocations/${id}/reject`, 'PUT');
    if (res.success) {
      showToast('Allocation request rejected', 'warning');
      loadAllocations();
    }
  } catch (error) {
    showToast(error.message || 'Failed to reject allocation', 'error');
  }
}

async function vacateAllocation(id) {
  if (!confirm('Are you sure you want to VACATE the student from this room?')) return;
  try {
    const res = await apiRequest(`/allocations/${id}/vacate`, 'PUT');
    if (res.success) {
      showToast('Student vacated from room', 'info');
      loadAllocations();
      loadDropdownData();
    }
  } catch (error) {
    showToast(error.message || 'Failed to vacate student', 'error');
  }
}

// Modal helper controls
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'flex';
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}
