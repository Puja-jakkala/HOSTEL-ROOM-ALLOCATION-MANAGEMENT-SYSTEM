// Student Dashboard Controller

let studentProfile = null;

document.addEventListener('DOMContentLoaded', () => {
  requireStudent();

  // Load student profile & allocations
  initStudentDashboard();
});

async function initStudentDashboard() {
  try {
    // 1. Fetch Student Profile
    const profileRes = await apiRequest('/student/profile', 'GET');
    if (profileRes.success && profileRes.data) {
      studentProfile = profileRes.data;
      renderStudentProfile(studentProfile);
      
      // 2. Fetch allocations for this student
      await loadStudentAllocation();
    }
  } catch (error) {
    showToast('Failed to load student profile', 'error');
    console.error(error);
  }
}

function renderStudentProfile(profile) {
  document.getElementById('profile-name').textContent = profile.name;
  document.getElementById('profile-roll').textContent = profile.student_id;
  document.getElementById('profile-email').textContent = profile.email;
  document.getElementById('profile-phone').textContent = profile.phone;
  document.getElementById('profile-gender').textContent = profile.gender;
  document.getElementById('profile-course').textContent = `${profile.department} - ${profile.course}`;
  document.getElementById('profile-year').textContent = `${profile.year} Year`;
  document.getElementById('profile-emergency').textContent = profile.emergency_contact;
  document.getElementById('profile-address').textContent = profile.address;
}

function formatFloor(floorNum) {
  const f = parseInt(floorNum);
  if (isNaN(f)) return floorNum;
  if (f === 1) return '1st Floor';
  if (f === 2) return '2nd Floor';
  if (f === 3) return '3rd Floor';
  return `${f}th Floor`;
}

function formatDate(dateString) {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
}

async function loadStudentAllocation() {
  const allocationCard = document.getElementById('allocation-card-content');
  if (!allocationCard) return;

  allocationCard.innerHTML = '<p>Loading allocation details...</p>';

  try {
    const res = await apiRequest('/student/my-allocation', 'GET');
    
    if (res.success) {
      const activeAlloc = res.data;

      if (activeAlloc) {
        if (activeAlloc.status === 'Approved') {
          allocationCard.innerHTML = `
            <div style="color: white;">
              <h3 style="font-size: 18px; margin-bottom: 16px; font-weight: 600;">Room Allocation Details</h3>
              <p style="margin: 8px 0; font-size: 15px;">• Allocation Status: Approved</p>
              <p style="margin: 8px 0; font-size: 15px;">• Room Number: ${activeAlloc.room_number}</p>
              <p style="margin: 8px 0; font-size: 15px;">• Block: ${activeAlloc.block}</p>
              <p style="margin: 8px 0; font-size: 15px;">• Floor: ${formatFloor(activeAlloc.floor)}</p>
              <p style="margin: 8px 0; font-size: 15px;">• Room Type: ${activeAlloc.room_type}</p>
              <p style="margin: 8px 0; font-size: 15px;">• Allocation Date: ${formatDate(activeAlloc.allocation_date)}</p>
            </div>
          `;
        } else if (activeAlloc.status === 'Pending') {
          allocationCard.innerHTML = `
            <div style="text-align: center; padding: 16px;">
              <span class="badge badge-warning" style="margin-bottom: 12px;">Pending</span>
              <p style="font-weight: 600; color: #fbbf24; margin-bottom: 8px;">Room allocation is pending admin approval.</p>
              <p style="font-size: 14px; color: var(--text-muted);">Requested Room: <strong>Room ${activeAlloc.room_number}</strong> (${activeAlloc.block})</p>
            </div>
          `;
        } else if (activeAlloc.status === 'Rejected') {
          allocationCard.innerHTML = `
            <div style="text-align: center; padding: 16px;">
              <span class="badge badge-danger" style="margin-bottom: 12px;">Rejected</span>
              <p style="font-weight: 600; color: var(--color-danger); margin-bottom: 16px;">Room allocation request was rejected.</p>
              <button class="btn btn-primary" onclick="openApplyModal()">Apply Again</button>
            </div>
          `;
          preloadEligibleRooms();
        } else {
          // Vacated or other status
          allocationCard.innerHTML = `
            <div style="text-align: center; padding: 24px 0;">
              <p style="color: var(--text-muted); margin-bottom: 16px;">No room has been allocated yet.</p>
              <button class="btn btn-primary" onclick="openApplyModal()">Apply for Room Allocation</button>
            </div>
          `;
          preloadEligibleRooms();
        }
      } else {
        // No active allocations found
        allocationCard.innerHTML = `
          <div style="text-align: center; padding: 24px 0;">
            <p style="color: var(--text-muted); margin-bottom: 16px;">No room has been allocated yet.</p>
            <button class="btn btn-primary" onclick="openApplyModal()">Apply for Room Allocation</button>
          </div>
        `;
        preloadEligibleRooms();
      }
    } else {
      // No allocation records at all
      allocationCard.innerHTML = `
        <div style="text-align: center; padding: 24px 0;">
          <p style="color: var(--text-muted); margin-bottom: 16px;">No room has been allocated yet.</p>
          <button class="btn btn-primary" onclick="openApplyModal()">Apply for Room Allocation</button>
        </div>
      `;
      preloadEligibleRooms();
    }
  } catch (error) {
    allocationCard.innerHTML = '<p style="color: var(--color-danger);">Failed to load allocation info.</p>';
    console.error(error);
  }
}

// Fetch rooms matching student's gender for the application dropdown
async function preloadEligibleRooms() {
  const roomSelect = document.getElementById('apply-room-select');
  if (!roomSelect || !studentProfile) return;

  roomSelect.innerHTML = '<option value="">Loading rooms...</option>';

  try {
    const res = await apiRequest('/rooms', 'GET');
    if (res.success && res.data) {
      // Filter rooms that match gender type AND have vacancy AND not under maintenance
      const eligibleRooms = res.data.filter(room => 
        (room.gender_type === 'Co-Ed' || room.gender_type === studentProfile.gender) &&
        room.occupied_beds < room.capacity &&
        room.status !== 'Maintenance'
      );

      roomSelect.innerHTML = '<option value="">-- Choose Room --</option>';
      if (eligibleRooms.length === 0) {
        roomSelect.innerHTML = '<option value="">No matching rooms available</option>';
        return;
      }

      eligibleRooms.forEach(room => {
        roomSelect.innerHTML += `
          <option value="${room.id}">
            Room ${room.room_number} (Block ${room.block} - ${room.room_type} - ${room.capacity - room.occupied_beds} beds free)
          </option>
        `;
      });
    }
  } catch (error) {
    roomSelect.innerHTML = '<option value="">Failed to load rooms list</option>';
  }
}

// Modal actions
function openApplyModal() {
  const modal = document.getElementById('apply-modal');
  if (modal) modal.style.display = 'flex';
}

function closeApplyModal() {
  const modal = document.getElementById('apply-modal');
  if (modal) modal.style.display = 'none';
}

// Submit Application request
async function submitAllocationRequest(e) {
  e.preventDefault();
  const roomId = document.getElementById('apply-room-select').value;

  if (!roomId) {
    showToast('Please select a room', 'warning');
    return;
  }

  try {
    const res = await apiRequest('/allocations', 'POST', { room_id: parseInt(roomId) });
    if (res.success) {
      showToast('Allocation application submitted successfully', 'success');
      closeApplyModal();
      loadStudentAllocation();
    }
  } catch (error) {
    showToast(error.message || 'Failed to submit application request', 'error');
  }
}

// Bind application form
const applyForm = document.getElementById('apply-room-form');
if (applyForm) {
  applyForm.addEventListener('submit', submitAllocationRequest);
}
