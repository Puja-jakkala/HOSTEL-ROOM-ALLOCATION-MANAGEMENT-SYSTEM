const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret_key_12345';

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { 
    name, email, password, student_id, phone, 
    gender, department, course, year, address, emergency_contact 
  } = req.body;

  // Basic validation
  if (!name || !email || !password || !student_id || !phone || !gender || !department || !course || !year || !address || !emergency_contact) {
    return res.status(400).json({
      success: false,
      message: 'All fields are required'
    });
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    // Check if email already exists
    const [existingUser] = await connection.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Email is already registered'
      });
    }

    // Check if student_id already exists
    const [existingStudent] = await connection.query('SELECT id FROM students WHERE student_id = ?', [student_id]);
    if (existingStudent.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Student ID is already registered'
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Insert user
    const [userResult] = await connection.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      [name, email, hashedPassword, 'student']
    );
    const userId = userResult.insertId;

    // Insert student details
    await connection.query(
      `INSERT INTO students (user_id, student_id, phone, gender, department, course, year, address, emergency_contact, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')`,
      [userId, student_id, phone, gender, department, course, parseInt(year), address, emergency_contact]
    );

    await connection.commit();
    connection.release();

    return res.status(201).json({
      success: true,
      message: 'Registration successful! You can now log in.'
    });
  } catch (error) {
    await connection.rollback();
    connection.release();
    console.error('Registration error:', error);
    return res.status(500).json({
      success: false,
      message: error.code === 'ER_DUP_ENTRY' ? 'Duplicate entry error: Email or Student ID already exists' : 'Internal server error'
    });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required'
    });
  }

  try {
    // Check if user exists
    const [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const user = users[0];

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Sign Token
    const payload = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });

    // Respond in user-required format
    return res.json({
      success: true,
      token: token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router;
