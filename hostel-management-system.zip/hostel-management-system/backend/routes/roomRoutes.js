const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// Helper to determine/update status based on beds occupied
function getRoomStatus(occupied, capacity, currentStatus) {
  if (currentStatus === 'Maintenance') return 'Maintenance';
  if (occupied >= capacity) return 'Full';
  if (occupied > 0 && occupied < capacity) return 'Partially Occupied';
  return 'Available';
}

// GET /api/rooms
// Authenticated users can list/search/filter rooms
router.get('/', authMiddleware, async (req, res) => {
  const { block, type, status, gender } = req.query;

  let query = 'SELECT *, (capacity - occupied_beds) as available_beds FROM rooms WHERE 1=1';
  const queryParams = [];

  if (block) {
    query += ' AND block = ?';
    queryParams.push(block);
  }
  if (type) {
    query += ' AND room_type = ?';
    queryParams.push(type);
  }
  if (status) {
    query += ' AND status = ?';
    queryParams.push(status);
  }
  if (gender) {
    query += ' AND gender_type = ?';
    queryParams.push(gender);
  }

  query += ' ORDER BY room_number ASC';

  try {
    const [rooms] = await pool.query(query, queryParams);
    return res.json({
      success: true,
      message: 'Rooms retrieved successfully',
      data: rooms
    });
  } catch (error) {
    console.error('Error fetching rooms:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve rooms'
    });
  }
});

// POST /api/rooms
// Admin only. Create a room.
router.post('/', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const { room_number, block, floor, room_type, capacity, gender_type, status } = req.body;

  if (!room_number || !block || floor === undefined || !room_type || !capacity || !gender_type) {
    return res.status(400).json({
      success: false,
      message: 'Missing required room fields'
    });
  }

  // Determine capacity integer based on type if not explicitly set correctly
  let finalCapacity = parseInt(capacity);
  if (room_type === 'Single') finalCapacity = 1;
  else if (room_type === 'Double') finalCapacity = 2;
  else if (room_type === 'Triple') finalCapacity = 3;
  else if (room_type === 'Four Sharing') finalCapacity = 4;

  try {
    // Check if room number already exists
    const [existingRoom] = await pool.query('SELECT id FROM rooms WHERE room_number = ?', [room_number]);
    if (existingRoom.length > 0) {
      return res.status(400).json({
        success: false,
        message: `Room number ${room_number} already exists`
      });
    }

    const initialStatus = status || 'Available';

    const [result] = await pool.query(
      `INSERT INTO rooms (room_number, block, floor, room_type, capacity, occupied_beds, gender_type, status) 
       VALUES (?, ?, ?, ?, ?, 0, ?, ?)`,
      [room_number, block, parseInt(floor), room_type, finalCapacity, gender_type, initialStatus]
    );

    return res.status(201).json({
      success: true,
      message: 'Room created successfully',
      data: {
        id: result.insertId,
        room_number,
        block,
        floor,
        room_type,
        capacity: finalCapacity,
        occupied_beds: 0,
        available_beds: finalCapacity,
        gender_type,
        status: initialStatus
      }
    });

  } catch (error) {
    console.error('Error creating room:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create room'
    });
  }
});

// PUT /api/rooms/:id
// Admin only. Update room details.
router.put('/:id', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const roomId = req.params.id;
  const { room_number, block, floor, room_type, capacity, gender_type, status } = req.body;

  try {
    const [rooms] = await pool.query('SELECT * FROM rooms WHERE id = ?', [roomId]);
    if (rooms.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Room not found'
      });
    }

    const room = rooms[0];

    // Capacity mapping
    let finalCapacity = capacity !== undefined ? parseInt(capacity) : room.capacity;
    if (room_type && room_type !== room.room_type) {
      if (room_type === 'Single') finalCapacity = 1;
      else if (room_type === 'Double') finalCapacity = 2;
      else if (room_type === 'Triple') finalCapacity = 3;
      else if (room_type === 'Four Sharing') finalCapacity = 4;
    }

    // Safety check: Cannot decrease capacity below current occupied beds
    if (finalCapacity < room.occupied_beds) {
      return res.status(400).json({
        success: false,
        message: `Cannot decrease room capacity below current occupied beds (${room.occupied_beds})`
      });
    }

    const updatedRoomNumber = room_number || room.room_number;
    const updatedBlock = block || room.block;
    const updatedFloor = floor !== undefined ? parseInt(floor) : room.floor;
    const updatedRoomType = room_type || room.room_type;
    const updatedGenderType = gender_type || room.gender_type;
    
    // Determine new status
    let updatedStatus = status || room.status;
    updatedStatus = getRoomStatus(room.occupied_beds, finalCapacity, updatedStatus);

    // Uniqueness check for room number if modified
    if (room_number && room_number !== room.room_number) {
      const [existingRoom] = await pool.query('SELECT id FROM rooms WHERE room_number = ? AND id != ?', [room_number, roomId]);
      if (existingRoom.length > 0) {
        return res.status(400).json({
          success: false,
          message: `Room number ${room_number} is already in use by another room`
        });
      }
    }

    await pool.query(
      `UPDATE rooms 
       SET room_number = ?, block = ?, floor = ?, room_type = ?, capacity = ?, gender_type = ?, status = ? 
       WHERE id = ?`,
      [updatedRoomNumber, updatedBlock, updatedFloor, updatedRoomType, finalCapacity, updatedGenderType, updatedStatus, roomId]
    );

    return res.json({
      success: true,
      message: 'Room updated successfully'
    });

  } catch (error) {
    console.error('Error updating room:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update room'
    });
  }
});

// DELETE /api/rooms/:id
// Admin only.
router.delete('/:id', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const roomId = req.params.id;

  try {
    const [rooms] = await pool.query('SELECT occupied_beds FROM rooms WHERE id = ?', [roomId]);
    if (rooms.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Room not found'
      });
    }

    // Safety: Do not delete room if currently occupied
    if (rooms[0].occupied_beds > 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete room as it currently has allocated students'
      });
    }

    await pool.query('DELETE FROM rooms WHERE id = ?', [roomId]);

    return res.json({
      success: true,
      message: 'Room deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting room:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete room'
    });
  }
});

module.exports = router;
