const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// Helper to determine/update room status
function getRoomStatus(occupied, capacity, currentStatus) {
  if (currentStatus === 'Maintenance') return 'Maintenance';
  if (occupied >= capacity) return 'Full';
  if (occupied > 0 && occupied < capacity) return 'Partially Occupied';
  return 'Available';
}

// GET /api/allocations/my-allocation
// Retrieve the current logged-in student's room allocation details.
router.get('/my-allocation', authMiddleware, async (req, res) => {
  try {
    // 1. Fetch own student profile ID
    const [students] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No student profile found for your account.'
      });
    }

    const studentId = students[0].id;

    // 2. Fetch the student's latest allocation request (whether Pending, Approved, or Rejected)
    const [allocations] = await pool.query(
      `SELECT a.id, a.student_id, a.room_id, a.bed_number, a.request_date, a.approved_date, a.status,
              r.room_number, r.block, r.floor, r.room_type, r.capacity, r.occupied_beds
       FROM allocations a
       JOIN rooms r ON a.room_id = r.id
       WHERE a.student_id = ?
       ORDER BY a.created_at DESC
       LIMIT 1`,
      [studentId]
    );

    if (allocations.length === 0) {
      return res.json({
        success: true,
        message: 'No room has been allocated yet.',
        data: null
      });
    }

    return res.json({
      success: true,
      message: 'Allocation details retrieved successfully',
      data: allocations[0]
    });
  } catch (error) {
    console.error('Error fetching own allocation:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve your room allocation'
    });
  }
});

// GET /api/allocations
// Admin sees all. Student sees their own.
router.get('/', authMiddleware, async (req, res) => {
  try {
    let query = `
      SELECT a.*, a.request_date AS allocation_date,
             s.student_id as student_roll_no, s.gender as student_gender, s.phone as student_phone,
             u.name as student_name, u.email as student_email,
             r.room_number, r.block, r.floor, r.room_type, r.capacity, r.occupied_beds
      FROM allocations a
      JOIN students s ON a.student_id = s.id
      JOIN users u ON s.user_id = u.id
      JOIN rooms r ON a.room_id = r.id
    `;
    const queryParams = [];

    if (req.user.role !== 'admin') {
      // Find the student ID for this logged in user
      const [ownStudent] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
      if (ownStudent.length === 0) {
        return res.json({ success: true, message: 'No student profile found', data: [] });
      }
      query += ' WHERE a.student_id = ?';
      queryParams.push(ownStudent[0].id);
    }

    query += ' ORDER BY a.created_at DESC';

    const [allocations] = await pool.query(query, queryParams);
    return res.json({
      success: true,
      message: 'Allocations retrieved successfully',
      data: allocations
    });
  } catch (error) {
    console.error('Error fetching allocations:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve allocations'
    });
  }
});

// POST /api/allocations
// Apply (Student) or Allocate manually (Admin)
router.post('/', authMiddleware, async (req, res) => {
  const { student_id, room_id, bed_number, allocation_date } = req.body;

  let targetStudentId;
  let targetStatus = 'Pending'; // Student applications default to Pending

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // 1. Resolve student ID
    if (req.user.role === 'admin') {
      if (!student_id || !room_id || !bed_number || !allocation_date) {
        connection.release();
        return res.status(400).json({ success: false, message: 'All fields are required' });
      }
      targetStudentId = parseInt(student_id);
      targetStatus = 'Approved'; // Admin allocation is approved immediately
    } else {
      // It's a student applying
      if (!room_id) {
        connection.release();
        return res.status(400).json({ success: false, message: 'Room selection is required' });
      }
      // Get student profile
      const [studentProfile] = await connection.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
      if (studentProfile.length === 0) {
        connection.release();
        return res.status(400).json({ success: false, message: 'No student profile found for your account' });
      }
      targetStudentId = studentProfile[0].id;
      targetStatus = 'Pending';
    }

    // 2. Validate student has no active allocation (Pending or Approved)
    const [activeAllocations] = await connection.query(
      "SELECT id FROM allocations WHERE student_id = ? AND status IN ('Pending', 'Approved')",
      [targetStudentId]
    );

    if (activeAllocations.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Student already has an active allocation or a pending application'
      });
    }

    // 3. Fetch room details and lock the row for updates
    const [rooms] = await connection.query('SELECT * FROM rooms WHERE id = ? FOR UPDATE', [room_id]);
    if (rooms.length === 0) {
      connection.release();
      return res.status(404).json({ success: false, message: 'Room not found' });
    }

    const room = rooms[0];

    // Validate room status and capacity
    if (room.status === 'Maintenance') {
      connection.release();
      return res.status(400).json({ success: false, message: 'Room is currently under maintenance' });
    }

    if (room.occupied_beds >= room.capacity) {
      connection.release();
      return res.status(400).json({ success: false, message: 'No available beds in the selected room' });
    }

    // Optional Check: Gender alignment
    const [studentInfo] = await connection.query('SELECT gender FROM students WHERE id = ?', [targetStudentId]);
    const studentGender = studentInfo[0].gender;
    if (room.gender_type !== 'Co-Ed' && room.gender_type !== studentGender) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: `Gender mismatch. Room is reserved for ${room.gender_type}s, but student gender is ${studentGender}.`
      });
    }

    // 4. Set final bed number and date
    const finalBedNumber = bed_number ? parseInt(bed_number) : (room.occupied_beds + 1);
    const finalDate = allocation_date || new Date().toISOString().split('T')[0];

    // 5. Insert allocation
    const [allocResult] = await connection.query(
      `INSERT INTO allocations (student_id, room_id, bed_number, request_date, approved_date, status) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        targetStudentId,
        room_id,
        req.user.role === 'admin' ? finalBedNumber : null,
        new Date().toISOString().split('T')[0],
        req.user.role === 'admin' ? finalDate : null,
        targetStatus
      ]
    );

    // 6. If Admin allocated directly, increment occupied beds and update room status
    if (targetStatus === 'Approved') {
      const newOccupied = room.occupied_beds + 1;
      const newRoomStatus = getRoomStatus(newOccupied, room.capacity, room.status);

      await connection.query(
        'UPDATE rooms SET occupied_beds = ?, status = ? WHERE id = ?',
        [newOccupied, newRoomStatus, room_id]
      );
    }

    await connection.commit();
    connection.release();

    return res.status(201).json({
      success: true,
      message: targetStatus === 'Approved' ? 'Room allocated successfully' : 'Allocation request submitted successfully',
      data: {
        id: allocResult.insertId,
        student_id: targetStudentId,
        room_id,
        bed_number: req.user.role === 'admin' ? finalBedNumber : null,
        request_date: new Date().toISOString().split('T')[0],
        approved_date: req.user.role === 'admin' ? finalDate : null,
        status: targetStatus
      }
    });

  } catch (error) {
    await connection.rollback();
    connection.release();
    console.error('Allocation error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create allocation'
    });
  }
});

// PUT /api/allocations/:id/approve
// Admin only. Approve a request.
router.put('/:id/approve', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const allocationId = req.params.id;
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // 1. Fetch allocation
    const [allocs] = await connection.query('SELECT * FROM allocations WHERE id = ? FOR UPDATE', [allocationId]);
    if (allocs.length === 0) {
      connection.release();
      return res.status(404).json({ success: false, message: 'Allocation request not found' });
    }

    const allocation = allocs[0];

    if (allocation.status !== 'Pending') {
      connection.release();
      return res.status(400).json({
        success: false,
        message: `Cannot approve allocation. Current status is ${allocation.status}`
      });
    }

    // 2. Double check if student has another approved allocation in the meantime
    const [otherApproved] = await connection.query(
      "SELECT id FROM allocations WHERE student_id = ? AND status = 'Approved' AND id != ?",
      [allocation.student_id, allocationId]
    );
    if (otherApproved.length > 0) {
      // Auto-reject this since student already has an active room
      await connection.query("UPDATE allocations SET status = 'Rejected' WHERE id = ?", [allocationId]);
      await connection.commit();
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Student already has another active room allocation. This request has been auto-rejected.'
      });
    }

    // 3. Check room space
    const [rooms] = await connection.query('SELECT * FROM rooms WHERE id = ? FOR UPDATE', [allocation.room_id]);
    const room = rooms[0];

    if (room.occupied_beds >= room.capacity) {
      connection.release();
      return res.status(400).json({ success: false, message: 'Cannot approve. Room capacity has been filled.' });
    }

    if (room.status === 'Maintenance') {
      connection.release();
      return res.status(400).json({ success: false, message: 'Cannot approve. Room is in maintenance mode.' });
    }

    // 4. Determine bed number
    let finalBedNumber = req.body.bed_number;
    if (!finalBedNumber) {
      // Find currently taken beds in this room
      const [takenBedsResult] = await connection.query(
        "SELECT bed_number FROM allocations WHERE room_id = ? AND status = 'Approved'",
        [room.id]
      );
      const takenBeds = takenBedsResult.map(b => b.bed_number);
      
      // Find the first free bed number from 1 to capacity
      for (let i = 1; i <= room.capacity; i++) {
        if (!takenBeds.includes(i)) {
          finalBedNumber = i;
          break;
        }
      }
    }
    if (!finalBedNumber) {
      finalBedNumber = 1;
    }

    // 5. Update allocation status, bed number, and approved date
    const todayDate = new Date().toISOString().split('T')[0];
    await connection.query(
      "UPDATE allocations SET status = 'Approved', bed_number = ?, approved_date = ? WHERE id = ?",
      [finalBedNumber, todayDate, allocationId]
    );

    // 6. Update room beds and status
    const newOccupied = room.occupied_beds + 1;
    const newRoomStatus = getRoomStatus(newOccupied, room.capacity, room.status);
    await connection.query(
      'UPDATE rooms SET occupied_beds = ?, status = ? WHERE id = ?',
      [newOccupied, newRoomStatus, room.id]
    );

    await connection.commit();
    connection.release();

    return res.json({
      success: true,
      message: 'Allocation approved successfully'
    });

  } catch (error) {
    await connection.rollback();
    connection.release();
    console.error('Approval error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to approve allocation'
    });
  }
});

// PUT /api/allocations/:id/reject
// Admin only. Reject a request.
router.put('/:id/reject', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const allocationId = req.params.id;

  try {
    const [allocs] = await pool.query('SELECT status FROM allocations WHERE id = ?', [allocationId]);
    if (allocs.length === 0) {
      return res.status(404).json({ success: false, message: 'Allocation request not found' });
    }

    if (allocs[0].status !== 'Pending') {
      return res.status(400).json({
        success: false,
        message: `Cannot reject. Request status is already ${allocs[0].status}`
      });
    }

    await pool.query("UPDATE allocations SET status = 'Rejected' WHERE id = ?", [allocationId]);

    return res.json({
      success: true,
      message: 'Allocation request rejected'
    });
  } catch (error) {
    console.error('Rejection error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to reject allocation'
    });
  }
});

// PUT /api/allocations/:id/vacate
// Admin only. Vacate student from room.
router.put('/:id/vacate', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const allocationId = req.params.id;
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // 1. Fetch allocation
    const [allocs] = await connection.query('SELECT * FROM allocations WHERE id = ? FOR UPDATE', [allocationId]);
    if (allocs.length === 0) {
      connection.release();
      return res.status(404).json({ success: false, message: 'Allocation record not found' });
    }

    const allocation = allocs[0];

    if (allocation.status !== 'Approved') {
      connection.release();
      return res.status(400).json({
        success: false,
        message: `Cannot vacate. Allocation status is ${allocation.status} (must be Approved)`
      });
    }

    // 2. Update allocation status
    await connection.query("UPDATE allocations SET status = 'Vacated' WHERE id = ?", [allocationId]);

    // 3. Fetch room and decrement beds occupied
    const [rooms] = await connection.query('SELECT * FROM rooms WHERE id = ? FOR UPDATE', [allocation.room_id]);
    const room = rooms[0];

    const newOccupied = Math.max(0, room.occupied_beds - 1);
    const newRoomStatus = getRoomStatus(newOccupied, room.capacity, room.status);

    await connection.query(
      'UPDATE rooms SET occupied_beds = ?, status = ? WHERE id = ?',
      [newOccupied, newRoomStatus, room.id]
    );

    await connection.commit();
    connection.release();

    return res.json({
      success: true,
      message: 'Student vacated from room successfully'
    });

  } catch (error) {
    await connection.rollback();
    connection.release();
    console.error('Vacate error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to vacate student'
    });
  }
});

module.exports = router;
