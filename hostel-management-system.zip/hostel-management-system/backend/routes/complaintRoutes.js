const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// GET /api/complaints
// Admin sees all. Student sees their own.
router.get('/', authMiddleware, async (req, res) => {
  try {
    let query = `
      SELECT c.*, 
             s.student_id as student_roll_no,
             u.name as student_name, u.email as student_email
      FROM complaints c
      JOIN students s ON c.student_id = s.id
      JOIN users u ON s.user_id = u.id
    `;
    const queryParams = [];

    if (req.user.role !== 'admin') {
      const [ownStudent] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
      if (ownStudent.length === 0) {
        return res.json({ success: true, message: 'No student profile found', data: [] });
      }
      query += ' WHERE c.student_id = ?';
      queryParams.push(ownStudent[0].id);
    }

    query += ' ORDER BY c.created_at DESC';

    const [complaints] = await pool.query(query, queryParams);
    return res.json({
      success: true,
      message: 'Complaints retrieved successfully',
      data: complaints
    });
  } catch (error) {
    console.error('Error fetching complaints:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve complaints'
    });
  }
});

// POST /api/complaints
// Students only can file complaints
router.post('/', authMiddleware, roleMiddleware(['student']), async (req, res) => {
  const { category, title, description } = req.body;

  if (!category || !title || !description) {
    return res.status(400).json({
      success: false,
      message: 'Category, title, and description are required'
    });
  }

  const validCategories = ['Room', 'Food', 'Water', 'Electricity', 'Cleaning', 'Other'];
  if (!validCategories.includes(category)) {
    return res.status(400).json({
      success: false,
      message: `Invalid category. Must be one of: ${validCategories.join(', ')}`
    });
  }

  try {
    // Look up student internal ID
    const [students] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
    if (students.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No student profile associated with your user account'
      });
    }

    const studentId = students[0].id;

    const [result] = await pool.query(
      'INSERT INTO complaints (student_id, category, title, description, status) VALUES (?, ?, ?, ?, ?)',
      [studentId, category, title, description, 'Pending']
    );

    return res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully',
      data: {
        id: result.insertId,
        student_id: studentId,
        category,
        title,
        description,
        status: 'Pending'
      }
    });

  } catch (error) {
    console.error('Error submitting complaint:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to submit complaint'
    });
  }
});

// PUT /api/complaints/:id
// Admin only. Respond to complaint and update status.
router.put('/:id', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const complaintId = req.params.id;
  const { status, response } = req.body;

  if (!status) {
    return res.status(400).json({
      success: false,
      message: 'Status is required'
    });
  }

  const validStatuses = ['Pending', 'In Progress', 'Resolved', 'Rejected'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({
      success: false,
      message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`
    });
  }

  try {
    const [complaints] = await pool.query('SELECT * FROM complaints WHERE id = ?', [complaintId]);
    if (complaints.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found'
      });
    }

    await pool.query(
      'UPDATE complaints SET status = ?, response = ? WHERE id = ?',
      [status, response || null, complaintId]
    );

    return res.json({
      success: true,
      message: 'Complaint status updated successfully'
    });

  } catch (error) {
    console.error('Error updating complaint:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update complaint'
    });
  }
});

module.exports = router;
