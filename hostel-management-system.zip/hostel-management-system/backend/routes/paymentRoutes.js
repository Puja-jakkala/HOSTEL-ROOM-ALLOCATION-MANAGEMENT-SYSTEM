const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// GET /api/payments
// Admin sees all. Student sees only their own.
router.get('/', authMiddleware, async (req, res) => {
  try {
    let query = `
      SELECT p.*, 
             s.student_id as student_roll_no,
             u.name as student_name, u.email as student_email
      FROM payments p
      JOIN students s ON p.student_id = s.id
      JOIN users u ON s.user_id = u.id
    `;
    const queryParams = [];

    if (req.user.role !== 'admin') {
      const [ownStudent] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
      if (ownStudent.length === 0) {
        return res.json({ success: true, message: 'No student profile found', data: [] });
      }
      query += ' WHERE p.student_id = ?';
      queryParams.push(ownStudent[0].id);
    }

    query += ' ORDER BY p.payment_date DESC';

    const [payments] = await pool.query(query, queryParams);
    return res.json({
      success: true,
      message: 'Payments retrieved successfully',
      data: payments
    });
  } catch (error) {
    console.error('Error fetching payments:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve payments'
    });
  }
});

// POST /api/payments
// Students can record a simulated/mock payment.
router.post('/', authMiddleware, roleMiddleware(['student']), async (req, res) => {
  const { amount, payment_method, transaction_id, payment_date } = req.body;

  if (!amount || !payment_method || !transaction_id) {
    return res.status(400).json({
      success: false,
      message: 'Amount, payment method, and transaction ID are required'
    });
  }

  try {
    // Check if student profile exists
    const [students] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
    if (students.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No student profile associated with your user account'
      });
    }

    const studentId = students[0].id;

    // Check uniqueness of transaction ID
    const [existingTx] = await pool.query('SELECT id FROM payments WHERE transaction_id = ?', [transaction_id]);
    if (existingTx.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'A payment record with this Transaction ID already exists'
      });
    }

    const finalDate = payment_date || new Date().toISOString().split('T')[0];
    const status = 'Paid'; // Automatically record mock payments as Paid

    const [result] = await pool.query(
      `INSERT INTO payments (student_id, amount, payment_date, payment_method, transaction_id, status) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [studentId, parseFloat(amount), finalDate, payment_method, transaction_id, status]
    );

    return res.status(201).json({
      success: true,
      message: 'Payment details submitted successfully',
      data: {
        id: result.insertId,
        student_id: studentId,
        amount,
        payment_date: finalDate,
        payment_method,
        transaction_id,
        status
      }
    });

  } catch (error) {
    console.error('Error logging payment:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to log payment details'
    });
  }
});

// PUT /api/payments/:id
// Admin only. Can update status of a payment.
router.put('/:id', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const paymentId = req.params.id;
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({
      success: false,
      message: 'Status is required'
    });
  }

  const validStatuses = ['Paid', 'Pending', 'Failed'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({
      success: false,
      message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`
    });
  }

  try {
    const [payments] = await pool.query('SELECT * FROM payments WHERE id = ?', [paymentId]);
    if (payments.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Payment record not found'
      });
    }

    await pool.query('UPDATE payments SET status = ? WHERE id = ?', [status, paymentId]);

    return res.json({
      success: true,
      message: 'Payment status updated successfully'
    });

  } catch (error) {
    console.error('Error updating payment:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update payment status'
    });
  }
});

module.exports = router;
