const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// GET /api/admin/dashboard-stats
// Protect with auth and admin role
router.get('/dashboard-stats', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  try {
    // 1. Total Students
    const [[{ totalStudents }]] = await pool.query('SELECT COUNT(*) as totalStudents FROM students');

    // 2. Total Rooms
    const [[{ totalRooms }]] = await pool.query('SELECT COUNT(*) as totalRooms FROM rooms');

    // 3. Available Rooms (rooms with capacity > occupied_beds AND status != 'Maintenance')
    const [[{ availableRooms }]] = await pool.query(
      "SELECT COUNT(*) as availableRooms FROM rooms WHERE occupied_beds < capacity AND status != 'Maintenance'"
    );

    // 4. Occupied Rooms (rooms that have at least 1 occupant)
    const [[{ occupiedRooms }]] = await pool.query(
      "SELECT COUNT(*) as occupiedRooms FROM rooms WHERE occupied_beds > 0"
    );

    // 5. Pending Allocations
    const [[{ pendingAllocations }]] = await pool.query(
      "SELECT COUNT(*) as pendingAllocations FROM allocations WHERE status = 'Pending'"
    );

    // 6. Pending Complaints
    const [[{ pendingComplaints }]] = await pool.query(
      "SELECT COUNT(*) as pendingComplaints FROM complaints WHERE status = 'Pending'"
    );

    return res.json({
      success: true,
      message: 'Dashboard statistics loaded successfully',
      data: {
        totalStudents,
        totalRooms,
        availableRooms,
        occupiedRooms,
        pendingAllocations,
        pendingComplaints
      }
    });

  } catch (error) {
    console.error('Error fetching dashboard statistics:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to load dashboard statistics'
    });
  }
});

module.exports = router;
