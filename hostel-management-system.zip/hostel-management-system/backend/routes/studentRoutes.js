const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// GET /api/students
// Admin only. Returns a list of all students.
router.get('/', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  try {
    const [students] = await pool.query(
      `SELECT s.*, u.name, u.email 
       FROM students s 
       JOIN users u ON s.user_id = u.id 
       ORDER BY s.created_at DESC`
    );
    return res.json({
      success: true,
      message: 'Students retrieved successfully',
      data: students
    });
  } catch (error) {
    console.error('Error fetching students:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve students'
    });
  }
});

// GET /api/student/profile
// Returns the logged-in student's own profile details
router.get('/profile', authMiddleware, async (req, res) => {
  try {
    const [students] = await pool.query(
      `SELECT s.*, u.name, u.email 
       FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE s.user_id = ?`,
      [req.user.id]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found'
      });
    }

    return res.json({
      success: true,
      message: 'Student profile retrieved successfully',
      data: students[0]
    });
  } catch (error) {
    console.error('Error fetching own profile:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve profile details'
    });
  }
});

// GET /api/student/my-allocation
// Returns the logged-in student's current room allocation details
router.get('/my-allocation', authMiddleware, async (req, res) => {
  try {
    // 1. Fetch own student profile ID
    const [students] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No student profile found for your account.'
      });
    }

    const studentId = students[0].id;

    // 2. Fetch the student's latest allocation request (whether Pending, Approved, or Rejected)
    const [allocations] = await pool.query(
      `SELECT a.id, a.student_id, a.room_id, a.bed_number, a.request_date, a.approved_date, a.status,
              r.room_number, r.block, r.floor, r.room_type, r.capacity, r.occupied_beds
       FROM allocations a
       JOIN rooms r ON a.room_id = r.id
       WHERE a.student_id = ?
       ORDER BY a.created_at DESC
       LIMIT 1`,
      [studentId]
    );

    if (allocations.length === 0) {
      return res.json({
        success: true,
        message: 'No room has been allocated yet.',
        data: null
      });
    }

    const alloc = allocations[0];
    return res.json({
      success: true,
      message: 'Allocation details retrieved successfully',
      data: {
        status: alloc.status,
        room_number: alloc.room_number,
        block: alloc.block,
        floor: alloc.floor,
        room_type: alloc.room_type,
        allocation_date: alloc.approved_date || alloc.request_date
      }
    });
  } catch (error) {
    console.error('Error fetching own allocation:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve your room allocation'
    });
  }
});

// GET /api/students/:id
// Admin or the student themselves.
router.get('/:id', authMiddleware, async (req, res) => {
  const studentId = req.params.id;

  try {
    let query = `
      SELECT s.*, u.name, u.email 
      FROM students s 
      JOIN users u ON s.user_id = u.id 
      WHERE s.id = ?`;
    let queryParams = [studentId];

    // If student requests 'me', resolve using user_id from token
    if (studentId === 'me') {
      query = `
        SELECT s.*, u.name, u.email 
        FROM students s 
        JOIN users u ON s.user_id = u.id 
        WHERE s.user_id = ?`;
      queryParams = [req.user.id];
    }

    const [students] = await pool.query(query, queryParams);

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found'
      });
    }

    const student = students[0];

    // Auth check: Students can only view their own profile
    if (req.user.role !== 'admin' && student.user_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only view your own profile.'
      });
    }

    return res.json({
      success: true,
      message: 'Student retrieved successfully',
      data: student
    });
  } catch (error) {
    console.error('Error fetching student:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve student'
    });
  }
});

// POST /api/students
// Admin only. Create student profile + user account manually.
router.post('/', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const {
    name, email, password, student_id, phone,
    gender, department, course, year, address, emergency_contact, status
  } = req.body;

  if (!name || !email || !student_id || !phone || !gender || !department || !course || !year || !address || !emergency_contact) {
    return res.status(400).json({
      success: false,
      message: 'Missing required student fields'
    });
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    // Check email uniqueness
    const [existingUser] = await connection.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Email already exists'
      });
    }

    // Check student ID uniqueness
    const [existingStudent] = await connection.query('SELECT id FROM students WHERE student_id = ?', [student_id]);
    if (existingStudent.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Student ID already exists'
      });
    }

    // Hash password (default: Student@123 if not provided)
    const pass = password || 'Student@123';
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(pass, salt);

    // Create User
    const [userResult] = await connection.query(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
      [name, email, hashedPassword, 'student']
    );
    const userId = userResult.insertId;

    // Create Student Profile
    const [studentResult] = await connection.query(
      `INSERT INTO students (user_id, student_id, phone, gender, department, course, year, address, emergency_contact, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, student_id, phone, gender, department, course, parseInt(year), address, emergency_contact, status || 'Active']
    );

    await connection.commit();
    connection.release();

    return res.status(201).json({
      success: true,
      message: 'Student created successfully',
      data: {
        id: studentResult.insertId,
        user_id: userId,
        student_id,
        name,
        email
      }
    });

  } catch (error) {
    await connection.rollback();
    connection.release();
    console.error('Error creating student:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create student'
    });
  }
});

// PUT /api/students/:id
// Admin or the student themselves.
router.put('/:id', authMiddleware, async (req, res) => {
  const studentId = req.params.id;
  const {
    name, email, phone, gender, department, course, year, address, emergency_contact, status
  } = req.body;

  try {
    // 1. Get the current student record
    const [students] = await pool.query('SELECT * FROM students WHERE id = ?', [studentId]);
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    const student = students[0];

    // 2. Auth Role Check
    if (req.user.role !== 'admin') {
      // Find own student profile
      const [ownStudent] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
      if (ownStudent.length === 0 || ownStudent[0].id !== parseInt(studentId)) {
        return res.status(403).json({
          success: false,
          message: 'Access denied. You can only edit your own profile.'
        });
      }
    }

    const connection = await pool.getConnection();
    await connection.beginTransaction();

    // 3. If admin or user is updating user table fields (name, email)
    if (req.user.role === 'admin' || req.user.id === student.user_id) {
      // Email uniqueness check if email is modified
      if (email && email !== req.user.email && req.user.role === 'admin') {
        const [existingUser] = await connection.query('SELECT id FROM users WHERE email = ? AND id != ?', [email, student.user_id]);
        if (existingUser.length > 0) {
          connection.release();
          return res.status(400).json({
            success: false,
            message: 'Email already exists'
          });
        }
      }

      // Update users table
      const updatedName = name || req.user.name;
      const updatedEmail = email || req.user.email;
      await connection.query(
        'UPDATE users SET name = ?, email = ? WHERE id = ?',
        [updatedName, updatedEmail, student.user_id]
      );
    }

    // 4. Update students table
    // If student themselves editing, restrict changes to profile fields only
    const updatedPhone = phone !== undefined ? phone : student.phone;
    const updatedGender = gender !== undefined ? gender : student.gender;
    const updatedAddress = address !== undefined ? address : student.address;
    const updatedEmergency = emergency_contact !== undefined ? emergency_contact : student.emergency_contact;
    
    // Admin only fields
    const updatedDept = (req.user.role === 'admin' && department !== undefined) ? department : student.department;
    const updatedCourse = (req.user.role === 'admin' && course !== undefined) ? course : student.course;
    const updatedYear = (req.user.role === 'admin' && year !== undefined) ? parseInt(year) : student.year;
    const updatedStatus = (req.user.role === 'admin' && status !== undefined) ? status : student.status;

    await connection.query(
      `UPDATE students 
       SET phone = ?, gender = ?, department = ?, course = ?, year = ?, address = ?, emergency_contact = ?, status = ? 
       WHERE id = ?`,
      [
        updatedPhone, updatedGender, updatedDept, updatedCourse, 
        updatedYear, updatedAddress, updatedEmergency, updatedStatus, studentId
      ]
    );

    await connection.commit();
    connection.release();

    return res.json({
      success: true,
      message: 'Student profile updated successfully'
    });

  } catch (error) {
    console.error('Error updating student:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update student profile'
    });
  }
});

// DELETE /api/students/:id
// Admin only.
router.delete('/:id', authMiddleware, roleMiddleware(['admin']), async (req, res) => {
  const studentId = req.params.id;

  try {
    const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [studentId]);
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    const userId = students[0].user_id;

    // Delete the user from users table. Cascading foreign keys will clean up students, allocations, complaints, and payments tables.
    await pool.query('DELETE FROM users WHERE id = ?', [userId]);

    return res.json({
      success: true,
      message: 'Student and related accounts deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting student:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete student'
    });
  }
});

// GET /api/student/profile
// Returns the logged-in student's profile details
router.get('/profile', authMiddleware, roleMiddleware(['student']), async (req, res) => {
  try {
    const [students] = await pool.query(
      `SELECT s.*, u.name, u.email 
       FROM students s 
       JOIN users u ON s.user_id = u.id 
       WHERE s.user_id = ?`,
      [req.user.id]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found.'
      });
    }

    return res.json({
      success: true,
      data: students[0]
    });
  } catch (error) {
    console.error('Error fetching student profile:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve profile details.'
    });
  }
});

// GET /api/student/my-allocation
// Returns the logged-in student's current room allocation
router.get('/my-allocation', authMiddleware, roleMiddleware(['student']), async (req, res) => {
  try {
    // 1. Get student profile ID
    const [students] = await pool.query('SELECT id FROM students WHERE user_id = ?', [req.user.id]);
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student profile not found.'
      });
    }
    const studentId = students[0].id;

    // 2. Fetch latest room allocation
    const [allocations] = await pool.query(
      `SELECT a.id as allocation_id, a.bed_number, a.request_date, a.approved_date, a.status as allocation_status,
              r.room_number, r.block, r.floor, r.room_type, r.capacity, r.occupied_beds
       FROM allocations a
       JOIN rooms r ON a.room_id = r.id
       WHERE a.student_id = ?
       ORDER BY a.created_at DESC LIMIT 1`,
      [studentId]
    );

    if (allocations.length === 0) {
      return res.json({
        success: true,
        data: null
      });
    }

    const alloc = allocations[0];

    // Format floor and room type for display
    let displayFloor = alloc.floor;
    if (alloc.floor === 1) displayFloor = '1st Floor';
    else if (alloc.floor === 2) displayFloor = '2nd Floor';
    else if (alloc.floor === 3) displayFloor = '3rd Floor';
    else displayFloor = `${alloc.floor}th Floor`;

    let displayRoomType = alloc.room_type;
    if (alloc.room_type === 'Single') displayRoomType = 'Single';
    else if (alloc.room_type === 'Double') displayRoomType = '2 Sharing';
    else if (alloc.room_type === 'Triple') displayRoomType = '3 Sharing';
    else if (alloc.room_type === 'Four Sharing') displayRoomType = '4 Sharing';

    // use approved_date if approved, request_date otherwise
    const allocationDateVal = alloc.allocation_status === 'Approved' ? alloc.approved_date : alloc.request_date;

    return res.json({
      success: true,
      data: {
        status: alloc.allocation_status,
        room_number: alloc.room_number,
        block: alloc.block,
        floor: displayFloor,
        room_type: displayRoomType,
        allocation_date: allocationDateVal,
        bed_number: alloc.bed_number
      }
    });
  } catch (error) {
    console.error('Error fetching student my-allocation:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve your room allocation details.'
    });
  }
});

module.exports = router;
