const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

async function runMigration() {
  console.log('Starting database schema migration...');
  
  try {
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    const sqlContent = fs.readFileSync(schemaPath, 'utf8');

    // Split statements by semicolon, being careful of any comments or empty lines
    const statements = sqlContent
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'));

    const connection = await pool.getConnection();
    
    try {
      // Temporarily disable foreign key checks to safely drop/recreate tables
      await connection.query('SET FOREIGN_KEY_CHECKS = 0');
      
      for (const statement of statements) {
        console.log(`Executing SQL: ${statement.substring(0, 60)}...`);
        await connection.query(statement);
      }
      
      await connection.query('SET FOREIGN_KEY_CHECKS = 1');
      console.log('Database schema migrated and initialized successfully!');
    } finally {
      connection.release();
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

runMigration();
