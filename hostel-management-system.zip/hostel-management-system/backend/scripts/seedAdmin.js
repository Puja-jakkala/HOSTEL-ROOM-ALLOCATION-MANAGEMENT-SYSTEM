const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306'),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD === 'YOUR_MYSQL_PASSWORD' ? '' : (process.env.DB_PASSWORD || '')
};

const DB_NAME = process.env.DB_NAME || 'hostel_management';

async function seed() {
  let connection;
  try {
    console.log('Connecting to MySQL server...');
    connection = await mysql.createConnection(dbConfig);
    console.log('Connected to MySQL server.');

    // 1. Create database if not exists
    console.log(`Creating database "${DB_NAME}" if not exists...`);
    await connection.query(`CREATE DATABASE IF NOT EXISTS ${DB_NAME}`);
    await connection.query(`USE ${DB_NAME}`);

    // 2. Read and run schema.sql
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    if (fs.existsSync(schemaPath)) {
      console.log('Reading schema.sql...');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      
      // Clean up the sql and split by semicolons to execute individual queries.
      // Semicolons inside comments or strings could be issues, but schema.sql is simple.
      const cleanSchemaSql = schemaSql
        .split('\n')
        .map(line => line.trim())
        .filter(line => !line.startsWith('--'))
        .join(' ');

      const queries = cleanSchemaSql
        .split(';')
        .map(q => q.trim())
        .filter(q => q.length > 0);

      console.log('Running database schema queries...');
      for (const query of queries) {
        if (!query.toLowerCase().startsWith('create database') && !query.toLowerCase().startsWith('use')) {
          await connection.query(query);
        }
      }
      console.log('Database tables successfully verified/created.');
    } else {
      console.warn('schema.sql not found at ' + schemaPath + '. Skipping table initialization.');
    }

    // 3. Seed admin user
    const adminEmail = 'admin@hostel.com';
    const adminPassword = 'Admin@123';
    
    const [rows] = await connection.query('SELECT * FROM users WHERE email = ?', [adminEmail]);
    if (rows.length > 0) {
      console.log(`Admin user "${adminEmail}" already exists in the database.`);
    } else {
      console.log('Hashing admin password...');
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(adminPassword, salt);

      console.log('Creating default admin user...');
      await connection.query(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
        ['System Admin', adminEmail, hashedPassword, 'admin']
      );
      console.log('Default admin user successfully seeded.');
      console.log('--------------------------------------------------');
      console.log(`Credentials: \nEmail: ${adminEmail} \nPassword: ${adminPassword}`);
      console.log('--------------------------------------------------');
    }

  } catch (error) {
    console.error('Error during database seeding:', error);
  } finally {
    if (connection) {
      await connection.end();
      console.log('Connection closed.');
    }
  }
}

seed();
